#!/usr/bin/env python3
"""Baut das kleine LowBlock-Pack: Sidebar (Logo+Rahmen), Gem-/Geld-Symbole, lila Buttons, lila Plugin-Menue-Hintergrund.
Aufruf:  python3 pack-gen.py   ->  schreibt LowBlock-Pack.zip (+ src/main/resources/LowBlock-Pack.zip)
Benoetigt: Pillow, numpy, scipy.  Das Logo liegt in pack-src/logo-source.jpg (schwarzer Hintergrund wird freigestellt).
"""
import io, json, os, shutil, zipfile
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "pack-src")
VERSION = "1.8.0"

W = 180            # Breite der Sidebar in GUI-Pixeln (Glyph-Breite)
LOGO_H = 72        # Hoehe des Logos ueber der Sidebar (GUI-Pixel)
S = 4              # Aufloesung des Kopf-Bildes (Bildpixel pro GUI-Pixel)
C0 = (214, 150, 255, 255)   # aussen (hell)
C1 = (160, 84, 226, 255)    # Mitte
C2 = (104, 48, 160, 255)    # innen (dunkel)


def cutout(path):
    """Logo vom schwarzen Hintergrund loesen (weiche Kante), Staub entfernen, zuschneiden."""
    img = np.asarray(Image.open(path).convert("RGB")).astype(np.float32)
    lum = img.max(axis=2)
    alpha = np.clip((lum - 20.0) / 26.0, 0.0, 1.0)
    labels, n = ndimage.label(alpha > 0.5)
    if n:
        sizes = ndimage.sum(np.ones_like(labels), labels, index=range(1, n + 1))
        keep = np.zeros(n + 1, bool)
        for i, size in enumerate(sizes, start=1):
            keep[i] = size > 4000
        mask = ndimage.binary_dilation(keep[labels], iterations=4)
        alpha = alpha * mask
    rgb = np.where(alpha[..., None] > 0.02, np.clip(img / np.maximum(alpha[..., None], 0.35), 0, 255), 0)
    out = np.dstack([rgb, alpha * 255.0]).astype(np.uint8)
    im = Image.fromarray(out, "RGBA")
    return im.crop(im.getbbox())


def put(px, x, y, c):
    px[x, y] = c


def frame_sides(px, y0, y1):
    for y in range(y0, y1):
        for x, c in ((0, C0), (1, C1), (2, C2), (W - 3, C2), (W - 2, C1), (W - 1, C0)):
            px[x, y] = c


MAX_LINES = 15          # Minecraft zeigt hoechstens 15 Zeilen
BODY_FIRST = 0xE210     # Zeichen fuer "Kasten mit n Zeilen" = BODY_FIRST + n


def body_glyph(n):
    """Ein einziger durchgehender Kasten (Seiten + Unterkante) fuer n Zeilen a 9 Pixel, die Oberkante liegt im Titel-Bild."""
    h = n * 9
    im = Image.new("RGBA", (W, h), (0, 0, 0, 0))
    px = im.load()
    frame_sides(px, 0, h)
    for x in range(W):
        px[x, h - 3], px[x, h - 2], px[x, h - 1] = C2, C1, C0
    return im


def header_glyph(logo):
    """Logo (frei, transparenter Hintergrund) ueber dem 9 Pixel hohen Titelstreifen mit Oberkante und Seitenraendern."""
    total_h = LOGO_H + 9
    big = Image.new("RGBA", (W * S, total_h * S), (0, 0, 0, 0))
    ratio = logo.width / logo.height
    lw, lh = int(round(LOGO_H * S * ratio)), LOGO_H * S
    if lw > (W - 8) * S:
        lw = (W - 8) * S
        lh = int(round(lw / ratio))
    scaled = logo.resize((lw, lh), Image.LANCZOS)
    big.alpha_composite(scaled, ((W * S - lw) // 2, LOGO_H * S - lh))
    strip = Image.new("RGBA", (W, 9), (0, 0, 0, 0))
    px = strip.load()
    frame_sides(px, 0, 9)
    for x in range(W):
        px[x, 0], px[x, 1], px[x, 2] = C0, C1, C2
    big.alpha_composite(strip.resize((W * S, 9 * S), Image.NEAREST), (0, LOGO_H * S))
    return big


# ---------- Buttons (Escape-Menue, Titelbild, Optionen ...) ----------
def button_img(body, edge, hi):
    """200x20 Button: dunkler Koerper, lila Rand, oben/unten eine helle Kante."""
    im = Image.new("RGBA", (200, 20), edge)
    px = im.load()
    for y in range(1, 19):
        for x in range(1, 199):
            px[x, y] = body
    for x in range(1, 199):
        px[x, 1] = hi
        px[x, 18] = tuple(max(0, c - 18) for c in body[:3]) + (255,)
    for (x, y) in ((0, 0), (199, 0), (0, 19), (199, 19)):
        px[x, y] = (0, 0, 0, 0)
    return im


BTN_MCMETA = {"gui": {"scaling": {"type": "nine_slice", "width": 200, "height": 20, "border": 3}}}

# ---------- Plugin-Menues (Hintergrund ueber den Titel-Glyph) ----------
G_BG = (22, 14, 34, 255)        # Panel innen
G_SLOT = (12, 8, 20, 255)       # Slot-Feld
G_SLOT_EDGE = (74, 44, 112, 255)
GUI_CHARS = {3: "\uf8e3", 4: "\uf8e4", 5: "\uf8e5", 6: "\uf8e6"}
GUI_PAD = 4         # Panel ragt rundum so viele Pixel ueber die Vanilla-Flaeche hinaus (verdeckt kleine Versaetze)
GUI_NEG8, GUI_BACK = "\uf8e0", "\uf8e1"   # Zurueckschieben vor dem Glyph / zurueck an den Titelanfang


def gui_bg(rows):
    """Oberer Kasten der Plugin-Menues: durchgehende dunkle Flaeche mit lila Rand, bewusst OHNE einzelne Slot-Felder
    (so faellt ein Versatz von ein paar Pixeln nicht auf). Das Spielerinventar darunter bleibt das normale.
    WICHTIG: "height" im Font-Provider muss exakt der Bildhoehe entsprechen, sonst wird das Bild skaliert (und verrutscht)."""
    w = 176 + 2 * GUI_PAD
    h = 17 + rows * 18 + 2 * GUI_PAD
    im = Image.new("RGBA", (w, h), G_BG)
    px = im.load()
    for y in range(h):
        for x in range(w):
            d = min(x, y, w - 1 - x, h - 1 - y)
            if d == 0:
                px[x, y] = C0
            elif d == 1:
                px[x, y] = C1
            elif d == 2:
                px[x, y] = C2
    return im


def png(im):
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def main():
    logo = cutout(os.path.join(SRC, "logo-source.jpg"))
    logo.save(os.path.join(SRC, "logo-cutout.png"))
    sidebar = {"providers": [
        {"type": "bitmap", "file": "lowblock:font/sidebar-header.png", "height": LOGO_H + 9, "ascent": LOGO_H + 7, "chars": [""]},
        {"type": "space", "advances": {"": 0, "": -(W + 1), "": 5}},
    ]}
    for n in range(2, MAX_LINES + 1):
        sidebar["providers"].append({"type": "bitmap", "file": "lowblock:font/sidebar-body%d.png" % n, "height": n * 9, "ascent": 7, "chars": [chr(BODY_FIRST + n)]})
    icons = {"providers": [{"type": "bitmap", "file": "lowblock:font/icons.png", "height": 9, "ascent": 8, "chars": [""]}]}
    mcmeta = {"pack": {"pack_format": 34, "supported_formats": {"min_inclusive": 34, "max_inclusive": 99}, "min_format": 34, "max_format": 99, "description": "§5LowBlock §7für DuelNetwork §f" + VERSION}}
    pack_png = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    pack_png.alpha_composite(logo.resize((64, int(64 * logo.height / logo.width)), Image.LANCZOS), (0, 16))
    out = os.path.join(HERE, "LowBlock-Pack.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("pack.mcmeta", json.dumps(mcmeta, indent=1))
        z.writestr("pack.png", png(pack_png))
        z.writestr("assets/lowblock/font/sidebar.json", json.dumps(sidebar))
        z.writestr("assets/lowblock/font/icons.json", json.dumps(icons))
        for n in range(2, MAX_LINES + 1):
            z.writestr("assets/lowblock/textures/font/sidebar-body%d.png" % n, png(body_glyph(n)))
        z.writestr("assets/lowblock/textures/font/sidebar-header.png", png(header_glyph(logo)))
        # Buttons
        z.writestr("assets/minecraft/textures/gui/sprites/widget/button.png", png(button_img((26, 16, 40, 255), C1, (52, 34, 78, 255))))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/button_highlighted.png", png(button_img((70, 36, 112, 255), C0, (118, 70, 176, 255))))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/button_disabled.png", png(button_img((18, 14, 24, 255), (52, 40, 68, 255), (30, 24, 40, 255))))
        slider = {"gui": {"scaling": {"type": "nine_slice", "width": 200, "height": 20, "border": 3}}}
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider.png", png(button_img((18, 12, 28, 255), C2, (36, 24, 56, 255))))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_highlighted.png", png(button_img((26, 16, 40, 255), C1, (52, 34, 78, 255))))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider.png.mcmeta", json.dumps(slider))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_highlighted.png.mcmeta", json.dumps(slider))
        hnd = Image.new("RGBA", (8, 20), C1)
        hpx = hnd.load()
        for y in range(1, 19):
            for x in range(1, 7):
                hpx[x, y] = (70, 36, 112, 255)
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_handle.png", png(hnd))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_handle_highlighted.png", png(hnd))
        hmeta = {"gui": {"scaling": {"type": "nine_slice", "width": 8, "height": 20, "border": 3}}}
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_handle.png.mcmeta", json.dumps(hmeta))
        z.writestr("assets/minecraft/textures/gui/sprites/widget/slider_handle_highlighted.png.mcmeta", json.dumps(hmeta))
        for n in ("button", "button_highlighted", "button_disabled"):
            z.writestr("assets/minecraft/textures/gui/sprites/widget/%s.png.mcmeta" % n, json.dumps(BTN_MCMETA))
        # Slider, Handle, Textfelder
        W_ = "assets/minecraft/textures/gui/sprites/widget/"
        def put_sprite(name, im, meta):
            z.writestr(W_ + name + ".png", png(im))
            z.writestr(W_ + name + ".png.mcmeta", json.dumps({"gui": {"scaling": meta}}))
        nine = lambda w, h, b: {"type": "nine_slice", "width": w, "height": h, "border": b}
        tf = Image.new("RGBA", (200, 20), C2)
        ImageDraw.Draw(tf).rectangle((1, 1, 198, 18), fill=(12, 8, 20, 255))
        tf_hi = Image.new("RGBA", (200, 20), C0)
        ImageDraw.Draw(tf_hi).rectangle((1, 1, 198, 18), fill=(12, 8, 20, 255))
        put_sprite("text_field", tf, nine(200, 20, 1))
        put_sprite("text_field_highlighted", tf_hi, nine(200, 20, 1))
        # Plugin-Menues
        gp = [{"type": "space", "advances": {GUI_NEG8: -(8 + GUI_PAD), GUI_BACK: -(176 + 2 * GUI_PAD + 1 - 8 - GUI_PAD)}}]
        for rows, ch in GUI_CHARS.items():
            h = gui_bg(rows).height
            gp.append({"type": "bitmap", "file": "lowblock:font/gui%d.png" % rows, "height": h, "ascent": 13 + GUI_PAD, "chars": [ch]})
            z.writestr("assets/lowblock/textures/font/gui%d.png" % rows, png(gui_bg(rows)))
        z.writestr("assets/minecraft/font/default.json", json.dumps({"providers": gp}))
        with open(os.path.join(SRC, "icons.png"), "rb") as f:
            z.writestr("assets/lowblock/textures/font/icons.png", f.read())
    shutil.copy(out, os.path.join(HERE, "src/main/resources/LowBlock-Pack.zip"))
    # Vorschau (nur zum Ansehen, nicht im Pack)
    prev = Image.new("RGBA", (W * S, (LOGO_H + 9 + 9 * 9) * S), (40, 40, 48, 255))
    prev.alpha_composite(header_glyph(logo), (0, 0))
    prev.alpha_composite(body_glyph(9).resize((W * S, 9 * 9 * S), Image.NEAREST), (0, (LOGO_H + 9) * S))
    prev.save(os.path.join(SRC, "preview.png"))


if __name__ == "__main__":
    main()
