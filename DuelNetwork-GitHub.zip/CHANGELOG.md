# Änderungen 1.8.3

- **Shop-Seiten neu:** Kategorie und Seite hängen jetzt direkt am geöffneten Shop-Fenster (statt in einer Merk-Liste pro Spieler). Blättern in SMP- und Bau-Shop prüft nur noch, ob die angeklickte Seite noch offen ist; Fehler beim Laden einer Seite werden gemeldet und geloggt.

- **Klickbare Statistik:** Nach dem Duell steht im Chat nur „Du hast gewonnen!/verloren“ mit Elo-Kurzinfo und einem klickbaren **[Statistiken]**; erst ein Klick zeigt die volle Statistik im Chat. Kein Befehl nötig (`/matchstats` geht weiterhin).

- **Duell-Statistik nach jedem 1v1-Duell** (Ranked und Unranked): Kit, Modus, Dauer, Schaden, kassierter Schaden, Treffer, stärkster Treffer, übrige Herzen und Elo-Änderung; mit `/matchstats` jederzeit nochmal ansehen.
- **Schnelleres Matchmaking:** Suchbereich startet bei ±100, wächst alle 5 s um 75, nach 30 s (statt 60 s) wird gegen jeden gespielt.
- **Elo-Erklärung:** Im Ranked-Menü und nach dem Duell steht, ob der Gegner stärker/schwächer war.

- **Kit-Menü live:** Nach dem Klick aktualisiert sich das Menü sofort. Das Kit, in dem du wartest, ist rot und leuchtet („Du spielst dieses Kit“), die anderen zeigen „zu diesem Kit wechseln“ – Kit wechseln geht direkt, ohne vorher zu verlassen. Erneuter Klick auf das rote Kit bricht die Suche ab.
- **Elo unter jedem Kit** (nur Ranked-Ansicht); neues Modus-Symbol oben im Menü (Klick wechselt Ranked/Unranked).

- **Ranked-Fixes:** Beim Wechsel zwischen Ranked und Unranked (NPC oder /ranked) wird die alte Warteschlange verlassen; Texte und Profil sagen jetzt „Unranked“ statt „Casual“; Warteschlangen-Zustand wird beim Verlassen des Servers aufgeräumt.

- **Robustheit:** Menü-Items aus Materialien ohne Item-Form zeigen einen Platzhalter statt einen Fehler zu werfen; Event-Admin-Befehle mit ungültiger Minutenzahl brechen nicht mehr mit Fehler ab.

- **Shop-Seiten:** Im Bau-Shop wurden auch Blöcke ohne Item-Form (z. B. Wandschilder, Stängel) aufgelistet; dadurch brach das Laden bestimmter Seiten (ab Seite 3) ab. Solche Einträge werden jetzt gefiltert, Fehler beim Seitenwechsel werden geloggt.
- **Lobby-Rand:** Kein roter Border-Schimmer mehr in der Lobby, auch nicht kurz beim Beitritt.

- **XP getrennt:** SMP und Bau-SMP haben je ein eigenes XP-Level (wird beim Wechsel gespeichert/wiederhergestellt, auch nach Neustart). In Lobby, Duellen, Events und Parkour gibt es keine XP (Gewinn blockiert, Level 0). Bestehendes XP wird einmalig dem SMP zugeordnet.
- **Ranked/Unranked getrennte Warteschlangen:** pro Kit je eine Ranked- und eine Unranked-Queue.
- **Elo pro Kit:** Ranked-Duelle ändern die Elo des jeweiligen Kits (Start 1000); die Gesamt-Elo (Rangliste) summiert die Änderungen. Unranked und direkte Herausforderungen ändern keine Elo.
- **Matchmaking nach Elo:** Gegner mit ähnlicher Kit-Elo (Start ±100, +50 alle 5 s, nach 60 s unbegrenzt). Konfig: `duels.match-range-start`, `duels.match-range-step`, `duels.match-unlimited-after-seconds`.
- **Kit-Menü:** Elo wird nur in der Ranked-Ansicht gezeigt, Unranked zeigt keine Elo. Profil zeigt Elo je Kit; Season-Reset wirkt auch auf Kit-Elo.

# Änderungen 1.8.2

- **Sammelimport für NPC-Skins:** `/duelladmin npcskin all import` importiert alle gültigen `<typ>.yml`-Dateien aus `plugins/DuelNetwork/npc-skins/` in einem Schritt und meldet ungültige Dateien.
- Der Refresh bereits vorhandener NPCs prüft geladene Chunks gemeinsam und in kleinen Batches. Dateien vom PC müssen über das Server-Panel oder SFTP hochgeladen werden; ein Drag-and-drop in das Minecraft-Fenster ist ohne Client-Mod nicht möglich.

# Änderungen 1.8.1

- **NPC-Skins importieren:** Neben Minecraft-Spielernamen werden jetzt Mojang-Texture-Properties (Base64-Texture-Wert plus optionale Signatur) für Mannequin-NPCs unterstützt.
- **Admin-Befehle:** `/duelladmin npcskin <typ> import` lädt `plugins/DuelNetwork/npc-skins/<typ>.yml`; `/duelladmin npcskin <typ> clear` entfernt den Import und stellt den Spielernamen-Skin wieder her. Ein normaler Spielername-Befehl löscht ebenfalls zuvor importierte Texturen.
- Importierte Texture-Properties werden in `config.yml` gespeichert und beim Spawn/Refresh verwendet. Rohe PNG-Dateien können nicht direkt als NPC-Skin eingesetzt werden; die Skin-Plattform muss dafür eine Texture-Property bereitstellen.
- Vorhandene NPCs werden nur in bereits geladenen Chunks und in kleinen Batches über mehrere Ticks aktualisiert, statt alle Welten in einem Tick zu scannen.

# Änderungen 1.7.1

- **Fehler behoben – Gem-Shop landete im normalen Shop:** Die Menü-Erkennung (`Gui.isTitle`) hat „Shop“ auch in „Gem-Shop“ gefunden, deshalb hat der normale Shop die Klicks im Gem-Shop mitverarbeitet (Kosmetik, Rohstoffe und Kauf der Axt führten in den normalen Shop). Die Erkennung prüft jetzt den vollständigen Titelanfang.
- **Gem-Shop je nach Ort:**
  - **SMP / Bau-SMP:** nur Gem-Spitzhacke und Gem-Axt (plus Rohstoffe-Knopf, abschaltbar mit `gems.smp-ores: false`).
  - **Lobby, Duelle, Events, Parkour:** Kosmetik (Trims, Kill-Effekte) und Rohstoffe zum Ansehen; Werkzeuge gibt es dort nicht mehr. Rohstoffe lassen sich nur im SMP kaufen.
- Zurück-Knopf im Rohstoffe-Menü führt wieder in den Gem-Shop.

# Änderungen 1.7.0

- **`/tpatoggle`:** Teleport-Anfragen (`/tpa`, `/tpahere`) ein-/ausschalten; wer sie ausschaltet, bekommt keine mehr (gespeichert in `social.yml`).
- **Party-Chat `/pc <Text>`** und **Freunde-Chat `/fc <Text>`** (respektiert Mutes).
- **`/friend notify`:** Online-/Offline-Meldungen deiner Freunde ein-/ausschalten.
- **Nachrichten-Ton:** Wer per `/msg` oder `/r` angeschrieben wird, hört einen Ton.
- **Duell-Zusammenfassung:** Nach jedem gewerteten Duell bekommen beide Dauer, Treffer und Schaden beider Seiten (`duels.summary`).
- **Kit-Statistik:** Siege und Niederlagen pro Kit, sichtbar im `/stats`-Profil (Buch-Symbol).
- **Geplanter Neustart (`restart.*`, standardmäßig aus):** Ansagen 10/5/1 Minute und 30/10/5–1 Sekunden vorher, dann Kick, Speichern, Herunterfahren. Der Host muss den Server danach wieder starten (Neustart-Skript oder Panel-Auto-Restart).
- Unverändert gelassen: Home-Menü (hat schon Betten und Klicks), Backup-Rotation (gibt es schon, `backup.keep`), Spielerköpfe und `/back` (laut Wunsch).

# Änderungen 1.6.1

- **`/tpahere <Spieler>`:** Bittet einen anderen SMP-Spieler, sich zu dir zu teleportieren. Der andere nimmt mit `/tpa accept` (oder dem Klick-Button) an, `/tpa deny` lehnt ab. Gleiche Regeln wie `/tpa`: nur im SMP, nur im gleichen Modus (SMP / Bau-SMP), Combat sperrt, Teleport mit Verzögerung, Anfrage läuft nach `smp.tpa-expire-seconds` ab. Eine normale `/tpa`-Anfrage hat bei `/tpa accept` Vorrang.

# Änderungen 1.6.0

- **Texte anpassbar:** Die Chat-Texte von Freunden, Handel, Kosmetik und Seasons stehen jetzt in `messages.yml` (Farben mit `&`). Die Schlüssel werden beim Start automatisch ergänzt. Nicht ausgelagert sind Texte mit eingebauten Namen oder Zahlen und Menü-Beschriftungen.
- **Handels-Log:** Jeder abgeschlossene Handel steht mit Namen, Items und Geld in `trades.log`.
- **Kill-Effekte:** neu Totem-Funken und Notenregen.
- **Season-Belohnung:** Der Sieger einer Season bekommt zusätzlich die exklusive **Champion-Aura** (Kill-Effekt, nur so erhältlich).
- **`COMMANDS.md`:** Befehlsübersicht, aus der `plugin.yml` erzeugt.
- Nicht enthalten: Replays für Zuschauer, 2v2-Queue, Turniere.

# Änderungen 1.5.0

**Weniger Lag**
- **Aufräumen (`cleanup.*`):** Pro Chunk werden zu viele Boden-Items (Standard über 60, älteste zuerst) und zu viele erwachsene Tiere (über 40) entfernt – nie Tiere mit Namen, zahme, angeleinte, Pferde oder Babys. Läuft alle 60 s.
- **Eigene Messung:** Alle wiederkehrenden Plugin-Tasks (Sidebar, Boards, Locator, Parkour, Anti-Cheat u. a.) werden gemessen. `/dnwartung perf` zeigt die langsamsten mit Durchschnitt und Maximum; Tasks über `perf.warn-ms` (40) landen im Log. So sieht man ohne Profiler, ob das Plugin überhaupt Last verursacht.
- Parkour-Geister sind auf `ghosts.max-active` (12) gleichzeitige Läufe begrenzt.
- Geprüft, aber unverändert: Die Move-Handler brechen schon früh ab, Dateien werden schon im Hintergrund geschrieben, die Sidebar aktualisiert nur bei Änderungen.

**Neu**
- **`/stats [Spieler]`:** Profil-Menü mit Elo, Platz, Siegen/Niederlagen, Quote, Serie, Gems und Geld.
- **`/ranked`:** Schaltet zwischen Ranked und Casual um. In einem Duell mit mindestens einem Casual-Spieler bleibt die Elo beider unverändert (Siege/Niederlagen zählen weiter).
- **`/tutorial`:** 7 Seiten mit klickbarem Blättern, beim ersten Beitritt wird darauf hingewiesen (`welcome.*`), inklusive FPS-Tipp (Sodium/Lithium/Iris).

**Nicht umgesetzt:** 2v2-Queue, Turniere, `DuelFixes` zusammenführen, Config-Caching (ohne Messwerte kein belegter Nutzen).

# Änderungen 1.4.0

**Gem-Shop & Kosmetik**
- Im Gem-Shop gibt es keinen Admin-„+1000 Gems“-Button mehr (Admins nutzen `/gems give`). Die **Hammer-Schaufel** ist aus dem Shop entfernt – es gibt nur noch Gem-Spitzhacke und Gem-Axt. Admins zahlen ebenfalls den normalen Preis. Alte Schaufeln, die Spieler schon besitzen, funktionieren weiter.
- **Kosmetik-Shop** (Gem-Shop → Kosmetik): 
  - **Armor-Trims:** 14 Muster × 10 Materialien einzeln kaufbar. Der gewählte Trim liegt im Duell automatisch auf der Kit-Rüstung (Menü-Schalter „Trim im Duell“ an/aus, Vorschau im Menü).
  - **Kill-Effekte:** Flammen, Herzregen, Seelenwirbel, Feuerwerk, Blitz (nur Optik) am Ort deines Siegs.
  - **Rohstoffe & Erze** für Gems (Kohle, Kupfer, Eisen, Gold, Redstone, Lapis, Amethyst, Smaragd, Diamant, Netherit-Schrott) – nur im SMP.
- Daten: `cosmetics.yml`.

**Freunde (`/friend`, `/f`)**
- `add / accept / deny / remove / list`, Online-/Offline-Meldungen, Menü mit Köpfen: Linksklick Teleport-Anfrage (`/friend tpaccept`), Rechtsklick Duell, Shift+Links Party-Einladung, Shift+Rechts entfernen. Anfragen-Ansicht im Menü. Daten: `friends.yml`.

**Handel (`/trade`)**
- `/trade <Spieler>` → `/trade accept`. Zwei-Seiten-Menü, Geld per `/trade money <Betrag>`, beide müssen bestätigen, jede Änderung nimmt Bestätigungen zurück, Abbruch/Schließen/Quit gibt alles zurück. Nur im SMP bzw. Bau-SMP im gleichen Modus (Geld ist modusgebunden), nicht im Duell. Abgeschlossene Handel stehen im Server-Log.

**Seasons (`/season`)**
- Standard 30 Tage (`seasons.length-days`). Am Ende: Gems für die Top 10 (`seasons.rewards`, `seasons.rewards-top10`), weicher Elo-Reset (`seasons.elo-keep`), Ruhmeshalle. `/season end` (Admin) beendet manuell.

**Parkour-Geister**
- Dein Lauf wird aufgezeichnet; beim nächsten Start läuft dein Bestzeit-Geist (blau) und der Rekord-Geist (gold) mit – nur für dich sichtbar. Daten: `ghosts.yml`.

**Team-Werkzeuge**
- `/note <Spieler> <Text>` und `/notes <Spieler> [clear]` (Notizen pro Spieler, `notes.yml`).
- **Discord-Webhook** (`webhook.url`, `webhook.events`: anticheat, report, season, duel).

**Pack**
- Lila Plugin-Menü-Hintergrund nur oben, Spielerinventar bleibt Vanilla (siehe 1.3.1), Buttons/Textfelder lila.

**Noch nicht in 1.4.0** (für 1.5.0 vorgesehen): 2v2-Queue, Ranked/Casual, Turniere, Replays für Zuschauer, Sprachdatei, Zusammenführen von `DuelFixes`.

# Änderungen 1.3.1

**Leaderboard-Optik (Sidebar)**
- Nur noch **ein** etwas breiterer Rahmen um das gesamte Leaderboard – keine Füllungen, Linien oder Unterstreichungen mehr hinter einzelnen Zeilen.
- **LowBlock-Logo** über dem Leaderboard, Hintergrund transparent.
- Dafür ist ein kleines Minimal-Pack zurück (`LowBlock-Pack.zip`: nur Logo, Rahmen, Gem-/Münz-Icons; keine Item-Texturen). Der Pack-Server (`resourcepack.*`, `/texturen`) ist wieder da. Spieler ohne Pack sehen die normale Sidebar mit Zeichen (◆ / ●).
- **Lila-schwarze Buttons:** Alle Buttons (Escape-Menü, Optionen, Titelbild) haben ein einheitliches lila/schwarzes Design (normal, Hover, deaktiviert), dazu Slider, Slider-Griff und Textfelder.
- **Lila Plugin-Menüs:** Nur die Plugin-GUIs (NPC-Menüs, Verkaufen, Shops, Navigator, Party, Top-Listen …) bekommen einen lila Hintergrund mit passenden Slot-Feldern nur für den oberen Kasten – das Spielerinventar darunter bleibt normal (Pack des Spielers). Normale Kisten, Fässer usw. bleiben Vanilla. Der Hintergrund (nur der obere Menü-Kasten, das Spieler-Inventar bleibt Vanilla bzw. das Pack des Spielers) ist ein Titel-Zeichen (`PackHost.applyMenuBackground`), setzt `InventoryView#setTitle` einen Tick nach dem Öffnen und nur bei geladenem Pack.
- Sonst enthält das Pack nichts (keine Item-Texturen). `pack_format` jetzt 34–99.
- Pack lässt sich über `pack-gen.py` neu erzeugen (Logo-Höhe, Farben, Rahmenbreite einstellbar).
- Korrektur zu 1.3.0: „Ohne Texturpack“ gilt nur noch für Items und Menüs.

# Änderungen 1.3.0

**Ohne Texturpack**
- Das Texturpack ist komplett entfernt (PackHost, Pack-Server, Pack-Dateien, `resourcepack.*`, `/texturen`). Alles nutzt normale Minecraft-Items; die Sidebar nutzt normale Zeichen (◆ Gems, ● Geld).
- **Verkaufen-Menü:** Der Verkaufen-Button ist jetzt ein Smaragd statt grünem Farbstoff.

**Neu**
- **Hologramm-Ranglisten (`/board`, Admin):** `/board add <elo|wins|streak|kills|playtime|money|bau-money|gems|parkour [Map]>` stellt eine schwebende Top-10 an deiner Position auf (Text-Display, kein Zusatz-Plugin). `/board remove` (nächste im Umkreis), `list`, `refresh`. Aktualisierung alle `boards.refresh-seconds` (60 s) und nur bei Änderungen. Wöchentliche/monatliche Listen gibt es bewusst nicht.
- **`/spectate`:** Liste laufender Duelle bzw. `/spectate <Spieler>`; `/spectate leave` bringt zurück. Wird automatisch beendet, wenn das Duell endet.
- **`/duel history`:** Die letzten 10 Duelle mit Gegner, Kit, Ergebnis und Elo-Änderung.
- **`/dnwartung perf`:** TPS, MSPT, RAM, Chunks und Entities pro Welt.

**Weniger Lag**
- Arena-Reset läuft jetzt verteilt auf mehrere Ticks (`duels.reset-blocks-per-tick`, Standard 4000) und setzt nur Blöcke zurück, die sich geändert haben. Arenen werden während des Zurücksetzens nicht neu belegt. Best-of-Runden warten auf den Reset.

# Änderungen 1.2.6

- **Serien (Best of 1 / 3 / 5 / 7)** für 1v1-Duelle – nicht für FFA:
  - Normale Duelle: Der Herausforderer wählt im Kit-Menü (Item „Best of N“, Slot unten Mitte) die Serienlänge; Klick schaltet 1 → 3 → 5 → 7 durch. Der Gegner sieht die Auswahl und kann sie nicht ändern.
  - Party-1v1: Der Party-Leader stellt Best of im Party-Menü (neues Item daneben) oder im Kit-Menü vor dem Start ein.
  - Nach jeder gewonnenen Runde: Zwischenstand, Arena wird zurückgesetzt, beide bekommen Kit/Leben neu und einen 3-Sekunden-Countdown. Wer zuerst die nötigen Siege (2/3/4) hat, gewinnt die Serie. Die Statistik zählt die Serie einmal.
  - Das Zeitlimit wächst mit der Serienlänge; die Bossbar zeigt den Stand. Revanche übernimmt die Serienlänge. Zufalls-Warteschlange und Events bleiben Best of 1.
- **Party-Menü:** Party-Duel zeigt wieder ein Eisenschwert, Party-FFA ein Diamantschwert (vorher überschrieb das Party-Icon beide).

# Änderungen 1.2.5

**Anti-Cheat**
- Sammelmeldungen: Wiederholte Warnungen derselben Prüfung werden unterdrückt und alle 30 s als eine Zusammenfassung gesendet (`anticheat.alert-summary`, `alert-window`).
- Replay-Protokoll: Die letzten ~60 Bewegungen/Zustände vor einem Verstoß landen in `anticheat-replays/`; `/anticheat replay <Spieler>` zeigt das neueste (`anticheat.replay`, `replay-keep`).

**Komfort**
- `/daily`: Tagesbelohnung mit Serien-Bonus (Gems + Geld im aktuellen Modus), Erinnerung beim Beitritt.
- `/quests`: 3 Tagesquests (Blöcke abbauen, Monster, PvP-Kills, Parkour-Läufe) mit Gem-Belohnung.
- `/tpmenu`: Menü für Homes, /back, SMP, Lobby, Warps und Spieler (/tpa).
- `/sidebar` zum Ein-/Ausschalten gab es bereits.

**Wartung** (`/dnwartung`, nur Admins)
- `export`: CSV mit Geld (SMP/Bau), Gems, Kills, Toden, Spielzeit nach `export/`.
- `backup` / `backuptest`: Backup sofort erstellen bzw. das neueste auf Lesbarkeit und fehlende Dateien prüfen.
- `config`: Prüft die config.yml auf fehlende Schlüssel, falsche Typen, negative Werte, Tippfehler-Abschnitte (läuft auch beim Start).

# Änderungen 1.2.4
- **Geld schicken:** `/pay` (und Admin-Gutschriften) landen im Konto des Modus, in dem der Absender gerade ist. Im Bau-SMP kommt das Geld also auf das Bau-Konto des Empfängers.

- **Getrenntes Geld:** Normales Geld ist jetzt pro Modus getrennt – SMP und Bau-SMP haben je ein eigenes Konto (Bau-Konto startet mit dem Startguthaben). Gems bleiben global und gelten in allen Modi. Auktionshaus und Orders zahlen/erstatten immer im Konto der jeweiligen Zone; Orders können nur im passenden Modus beliefert werden. Baltop/Rang, Vault und PlaceholderAPI zeigen das SMP-Konto.
- **Gems überall:** Die Sidebar zeigt die Gems jetzt auch in Lobby, Parkour und Events.
- **Sidebar-Rahmen:** Nur noch ein Rand um das ganze Panel – keine Linie mehr unter jeder Zeile. Das LowBlock-Logo steht jetzt oben als Titel über dem Leaderboard. Resource-Pack Version 95.
- **Neuer Rang „Tester“:** `/rank <Spieler> Tester` (grünes [TESTER]-Präfix, Tab-Sortierung, 5 Homes).

# Änderungen 1.2.3

- **Sidebar als vollständiges Panel:** Jede Sidebar-Zeile erhält jetzt eine durchgehende lila-schwarze Hintergrundfläche mit Rahmen. Text, Leerzeilen, Logo und Trennlinien liegen dadurch in einem zusammenhängenden Panel statt auf einzelnen abgeschnittenen Linien.
- **Sidebar-Design:** Die Sidebar hat jetzt einen vollständigen lila-schwarzen Rahmen mit separaten linken und rechten Kanten für jede Inhaltszeile. Trennlinie und LowBlock-Logo wurden kontrastreicher gestaltet, damit das Panel nicht mehr abgeschnitten oder unvollständig wirkt.
- **Schaufelkopf finalisiert:** Der Gem-Schaufelkopf ist jetzt vollständig und symmetrisch wie bei einer Vanilla-Minecraft-Schaufel; nur die lila Gem-Farbgebung wurde angepasst.
- **Bau-SMP-Abbau:** Der allgemeine ProtectionListener erkennt die Bau-SMP-Zone jetzt als erlaubte Bauzone; Abbauen und Bauen funktionieren wieder außerhalb fremder Claims.
- **Gem-Haltbarkeit:** Der manuelle Verschleiß von 3x3-Hammer und Baum-Axt berücksichtigt jetzt Unbreaking X. Zusatzblöcke verbrauchen nicht mehr pauschal volle Haltbarkeit.
- **Gem-Schaufelmodell:** Die Schaufel verwendet jetzt das Minecraft-Handheld-Modell und wird im Client nicht mehr zu klein dargestellt.
- **Große Shop-Kataloge:** Bau-SMP-Overworld, Nether und End ergänzen automatisch alle passenden stapelbaren Minecraft-Blöcke und blättern dadurch über viele Seiten. Der normale SMP-Shop hat eine umfangreiche PvP-Ausrüstungskategorie mit teuren Waffen, Äxten, Bögen, Schilden, Mace, Trident und kompletten Rüstungssets.
- **Gem-Schaufel:** Schaufelkopf und Griff wurden als klar erkennbare lila Minecraft-Pixeltextur neu gezeichnet und in die JAR eingebettet.
- **Party-Icons korrigiert:** Party-Duel (1v1) zeigt ein Eisenschwert, Party-FFA ein Diamantschwert.
- **Shop-Ausbau:** Normaler SMP-Shop hat eine blätterbare Blocks-Kategorie; der Bau-Shop enthält deutlich mehr Baumaterialien und Seiten.
- **Performance:** Sidebar-, Inventar- und Parkour-Refresh laufen seltener, ohne die Anzeigenfunktion zu verlieren, damit der Hauptthread bei mehreren Testspielern weniger belastet wird.
- **Gem-Werkzeuge:** Unbreaking X und niedrigere Preise (750/750/450 Gems) machen Hammer-Spitzhacke, Fäller-Axt und Hammer-Schaufel deutlich langlebiger und fairer.
- **Shop erweitert:** Bau-SMP enthält jetzt viele weitere Overworld-, Nether- und End-Baublöcke, darunter Calcit, Tuff, Deepslate-Varianten, Holzsorten und Purpur-Varianten. Kategorien haben Seitenwechsel. Glowstone-Blöcke sind auch im normalen Nether-Katalog verfügbar.
- **Event-Erkennung:** 1v1-/Turnier-Anmeldungen verwenden ein Eisenschwert, FFA ein Diamantschwert.
- **Bau-SMP-Sidebar:** Geld und Gems werden auch im freien Baumodus angezeigt.
- **Gem-Schaufel:** Fehlendes `gem_shovel`-Modell, Textur und Plugin-Zuordnung für `Hammer-Schaufel` ergänzt.
- **Lila Spezialdesign:** Gem-Spitzhacke, Gem-Axt und Gem-Schaufel verwenden jetzt eine gemeinsame violette Kristallpalette mit Vanilla-Pixelkonturen.
- **Texturepack für DuelNetwork 1.2.3:** Das Pack ist nicht mehr nur mit einer internen Packnummer beschriftet, sondern nennt direkt die zugehörige Plugin-Version.
- **Icon-Feinschliff:** Menüfarben wurden leicht gedämpft und stärker an Minecraft-Pixelpaletten angeglichen.
- **Refresh-Fix:** Nach GUI-Klicks und verzögerten Inventaränderungen werden Item-Modelle mehrfach erneut angewendet, damit Spezialtexturen nicht verschwinden.

# Änderungen 1.2.2

- **Automatischer Resourcepack-Versand:** Das Pack wird beim Join ohne `/texturen` gesendet.
- **Join-Retries:** Der Versand wartet bei verspäteter IP-Ermittlung und versucht die URL bis zu 20-mal erneut.
- **Diagnose:** `/texturen status` zeigt die verwendete Download-URL und den letzten Client-Status. Für Server hinter Proxy/NAT wird eine direkte HTTPS-URL über `resourcepack.url` empfohlen.

# Änderungen 1.2.1

- **Gem-Textur:** Die bereitgestellte Gem-Grafik wurde pixelgenau übernommen, dezent abgedunkelt und als 16x16- sowie Sidebar-Textur eingebunden.
- **Texturepack:** Pack-Version 92; vorhandene Plugin-Icons bleiben im klaren, reduzierten Minecraft-Pixelstil.
- **Nether/End-Sperre:** Solange eine Dimension nicht freigeschaltet ist, sind `/rtp` dorthin, `/rtp` innerhalb der Dimension und Portale in beide Richtungen blockiert.

# Änderungen 1.2.0

- **Claims-/Land-Schutz:** Rechteckige X/Z-Claims ausschließlich im Bau-SMP mit Überschneidungs-, Größen- und Spielerlimitprüfung; das normale PvP-SMP bleibt unverändert.
- **Lokale Rollen:** `owner`, `member` und `trusted`; `/claim create`, `info`, `list`, `trust`, `untrust`, `delete` und `abandon`.
- **SQLite:** Claims werden in `claims.db` mit WAL, Foreign Keys, Schema-Version und Audit-Tabelle gespeichert.
- **Schutz:** Bauen, Abbauen, Container, Türen/Redstone, Flüssigkeiten, Item-Frames, Rüstungsständer, PvP, Explosionen, Pistons und mobbedingte Blockänderungen.
- **Zonen-Ausnahmen:** Lobby, Duelle, Parkour und Bau-SMP werden nicht durch Claims beeinflusst; `duelnetwork.claim.bypass` ist der explizite Admin-Bypass.
- **Config:** Migrationsstand auf Version 8 erhöht.

# Änderungen 1.1.7

- **Transaktionale Economy:** Konten werden in `economy.db` (SQLite, WAL, `synchronous=FULL`) gespeichert. Alle Gutschriften, Abbuchungen und Admin-Setzungen schreiben atomar in Konto und Ledger.
- **Idempotenter Ledger:** Jede Geldänderung besitzt eine eindeutige Transaktions-ID und kann nach einem Prozessabbruch sicher wiederholt werden, ohne doppelte Gutschriften.
- **Recovery-Journal:** Orders und Auktionshaus führen `PENDING`/`COMMITTED`-Transaktionen; offene Einträge werden beim nächsten Start automatisch fortgesetzt.
- **Migration:** Bestehende Konten aus `economy.yml` werden beim ersten Start in SQLite übernommen. `economy.yml` bleibt als lesbares Backup erhalten.
- **Standalone-JAR:** Der SQLite-Treiber ist in der Plugin-JAR enthalten.

# Änderungen 1.1.6

- **Arena-Schutz:** Duel-Arenen werden vor dem Snapshot auf maximal 100.000 Blöcke begrenzt; übergroße oder überlaufende Bereiche werden sicher abgelehnt.
- **Crash-Sicherheit:** Orders und Auktionshaus speichern kritische Zustandsänderungen vor Gutschriften bzw. Auszahlungen und warten auf den I/O-Flush, um Wiederholungs-Duplikationen nach harten Neustarts zu verhindern.
- **Async-Stabilität:** Anti-Cheat- und Home-Chat-Meldungen greifen nicht mehr direkt aus dem Async-Chat-Thread auf Player-APIs zu.
- **PackHost:** Der eigene HTTP-Executor wird beim Deaktivieren des Plugins sauber beendet.

# Änderungen 1.1.5

- **Texture-Pack v91:** Gem als runder Schliff mit Ringen (wie eine Zielscheibe) in Lila, auch als kleines Sidebar-Symbol.

# Änderungen 1.1.4

- **Verkaufs-Menü (/sell):** Beim Einlegen von Items verschwanden die Texturen der Buttons. Ursache: Die Buttons wurden bei jedem Klick ohne Pack-Modell neu gesetzt. Behoben; andere Menüs, die ihre Buttons nach einem Klick neu setzen, bekommen ihre Modelle jetzt ebenfalls wieder.
- **Texture-Pack v90:** Gem neu gezeichnet (Smaragd-Form mit Vanilla-ähnlichen Facetten, in Lila), Neustart-Pfeil mit klarer Spitze, neues Party-Icon (Partytröte mit Konfetti), Parkour nutzt wieder die Vanilla-Feder.

# Änderungen 1.1.3

- **Auktionshaus:** Sortierung (neueste, günstigster oder teuerster Stückpreis) per Knopf unten, Stückpreis im Tooltip bei Stapeln.
- **Anti-Cheat:** `/anticheat status <Spieler>` zeigt wie `info` die Verstöße; Bestrafungen landen zusätzlich im Audit-Log; `ban-duration` ist jetzt auf 3 Tage voreingestellt (nur relevant bei `punishment: ban`).
- **/rank:** Spielernamen werden nur noch aus dem Cache gelesen (kein Mojang-Aufruf im Haupt-Thread).
- **Gem-Werkzeuge:** Der Hinweis „Werkzeug fast kaputt" erscheint in der Actionbar statt im Chat.

# Änderungen 1.1.2

## 1.8.0

- **Spuren für Enderperlen:** Pfeile und Enderperlen haben jetzt je eine eigene Spur (im Spuren-Menü Knopf "Spur für: Pfeile/Enderperlen"; gekaufte Spuren gelten für beide). Ohne eigene Auswahl nutzt die Perle weiter die Pfeil-Spur. Schnelle Projektile werden zwischen zwei Ticks mit Partikeln aufgefüllt, damit die Spur der Perle durchgehend ist.

- **Mehr Kosmetik:** 4 neue Armor-Trim-Muster (Plünderer, Gastgeber, Strömung, Blitzschlag; jetzt alle 18), 7 neue Kill-Effekte (Schneewirbel, Zauberfunken, Funkenregen, Kirschblüten, Drachenhauch, Elektro-Funken, Portal-Wirbel) und 7 neue Projektil-Spuren (Schneeflocken, Zauberspur, Kirschblüten, Elektro-Funken, Portal-Spur, Lava-Tropfen, Drachenhauch). Effekte und Spuren je 14 statt 7; beide Menüs haben jetzt 36 Plätze (Zurück/Aus unten).
- **Shop-Seiten überarbeitet:** "Nächste Seite" erscheint nur, wenn es eine gibt; neu: Erste/Letzte Seite (ab 4 Seiten) und Shift-Klick = 5 Seiten springen; Blättern und Kaufen füllen das offene Fenster nur neu (Maus bleibt an der Stelle, kein Flackern). Gilt für Shop und Bau-Shop.

- **Aufheben im SMP korrigiert:** Das Zusammenlegen passiert jetzt NUR noch beim Aufsammeln: das aufgehobene Item landet direkt auf einem vorhandenen, nicht vollen Stapel desselben Items (kein Nachbar-Slot mehr). Das automatische Zusammenführen aller Stapel alle paar Sekunden wurde entfernt: Stapel, die du selbst teilst, bleiben getrennt; nichts passiert beim Rausnehmen aus Kisten oder Verschieben im Inventar.
- **Duell-Lobby:** Der Duelle-NPC (`/duelladmin npc duell`) und der Navigator-Eintrag "Duelle" (Kompass) teleportieren in die Duell-Lobby (`/duelladmin setlobby duell`; ohne gesetzte Lobby öffnet sich die Kit-Auswahl). Dort stehen die NPCs **Ranked**, **Unranked** und **Teams** (`/duelladmin npc ranked|unranked|team`). NPC-Namen umbenannt (Duelle, Ranked, Unranked, Teams); nach dem Update `/duelladmin npcfix`/Namen-Refresh bzw. Neustart. Aliase: `npc duelle`, `npc teams`.
- **`/gems` jetzt auch in der Lobby:** öffnet den Gem-Shop mit Kosmetik (Armor-Trims, Kill-Effekte, Spuren); Spitzhacke und Axt gibt es nur im SMP. Kosmetik landet nie im Inventar: ansehen, kaufen, auswählen über `/cosmetics` oder den Gem-Shop.

- **SMP: Items beim Aufheben sofort zusammengelegt:** Die Wert-Zeile im Item verhinderte, dass neue Items auf vorhandene Stapel kamen (erst nach einigen Sekunden). Jetzt wird 1 Tick nach dem Aufheben sofort zusammengeführt und neu beschriftet.
- **Goals angepasst:** Tagesaufgaben gibt es schon als `/quests`, deshalb sind die eigenen standardmäßig aus (`goals.daily-enabled: false`); Wochenziele und Erfolge bleiben. Gem-Belohnungen auf das Niveau des Plugins gesenkt (je 10). Die Sidebar-Zeile "Aufgaben" zeigt die `/quests`. Alias-Konflikt mit `/aufgaben` behoben.
- **Neu:** `/share [Text]` (Freunde bekommen anklickbaren Teleport zu deinem Ort, 10 Min.), `/claim map` (Textkarte der Chunks), `/gems history` (letzte 10 Änderungen mit Herkunft, seit Neustart), `/duel last` (letztes Kit erneut), Config-Check meldet fehlende neue Einstellungen.

- **Aufgaben-System ausgebaut:** 2 Wochenziele (`goals.weekly-gems`), Serien-Bonus für aufeinanderfolgende Tage mit allen Tagesaufgaben (`goals.streak-gem-step`), 6 weitere Erfolge (Siegesserien, Kopfgeld, Event-Sieg, Claim, Aufgaben-Serie) mit wählbarem Chat-Titel (`/goals title <id>`), Sidebar-Zeile "Aufgaben: x/3".
- **Duell-Zusammenfassung** (Schaden und Treffer) nach 1v1-Duellen; **Todes-Hinweis** mit Klick zum Kopieren der Grabstein-Koordinaten; **Lag-Warnung** für Admins (`lag.*`) mit den langsamsten Plugin-Aufgaben.

- **Tagesaufgaben & Erfolge (`/goals`):** täglich 3 Aufgaben pro Spieler (Duelle gewinnen, Monster, Blöcke im SMP, Parkour, Spielminuten) mit Gems, dazu 6 einmalige Erfolge (`goals.*`). Meldung nur bei Abschluss.
- **`/settings`:** Menü für Claim-Hinweis, @Name-Ping, Kopfgeld-Meldungen und Modus-Hinweise.
- **Unbekannter Befehl:** "Meintest du /duel?" für Befehle dieses Plugins.
- **Admin:** `/duelnetwork maintenance [on|off]` (neue Duelle pausieren, laufende enden normal) und `/duelnetwork report` (schreibt `fehlerbericht.txt` mit Version, Config-Hinweisen und den letzten 30 Fehlern).

- **Feinschliff:** Erstes-Mal-Hinweise je Modus (`hints.enabled`, einmal pro Spieler, `hints.yml`); `/duelnetwork matches` zeigt laufende Duelle, Warteschlangen, Event und Parkour; Elo-Verlauf (Sparkline der letzten 20 gewerteten Duelle) in der Duell-Historie; Webhook-Ereignis `event` (Start und Sieger).

- **Stabilität/Diagnose:** `ConfigCheck` meldet beim Start und bei `/duelnetwork reload` falsche Typen, unsinnige Zahlen und unbekannte Abschnitte (nur Hinweise, nichts wird geändert). `/duelnetwork info` zeigt zusätzlich Spieler je Modus, Welten, Bau-SMP-Art (eigene/geteilte Welt), Fehleranzahl seit Start und Config-Status. Sidebar zeigt in Lobby und SMP "Party: x online", wenn man in einer Party ist. (Speichern im Hintergrund, Backups und Debug-Modus gab es schon.)

- **Schlaf-System, Teil 2:** Abstimmung als Bossbar (`sleep.bossbar`), nur für Mitzählende; bei einem einzelnen Spieler fast sofort; Mitschläfer bekommen kurz Regeneration und optional Gems (`sleep.reward-gems`, Standard 0); Bau-Schlafwünsche verfallen sauber (Moduswechsel, Offline, 60 s).

- **Schlaf-System verbessert:** Anzeige aktualisiert sich sofort, wenn jemand aufsteht; Nacht wird nach kurzer Wartezeit nur übersprungen, wenn dann noch genug schlafen; weicher Zeitraffer statt Sprung (`sleep.smooth`, nicht bei geteilter Welt mit Bau-SMP); Phantom-Zähler wird nach dem Schlafen zurückgesetzt.

- **Tag/Nacht nur im SMP und Bau-SMP (auch in einer gemeinsamen Welt):** Lobby, Duell, Event und Parkour sehen immer Mittag und klares Wetter (Spielerzeit). SMP folgt der echten Weltzeit. Das Bau-SMP hat in einer geteilten Welt eine eigene Uhr (`time.bau-offset`) und schläft getrennt: Rechtsklick aufs Bett bei Bau-Nacht = Schlafwunsch, ab `sleep.percent` der Bau-Spieler wird es Morgen. Schlafen im SMP verschiebt die Bau-Uhr nicht. Grenzen: Mobs, Pflanzen und Wetter folgen der echten Weltzeit.
- Rohstoff-&Erze-Shop aus dem Gem-Shop entfernt. Trim-Materialien (Quarz bis Netherit) wählt man weiterhin im Kosmetik-Menü unter Armor-Trim.
- GUI-Fix: Menue-Hintergrund exakt auf die Item-Positionen abgestimmt (Ursache: Glyph-Hoehe != Bildhoehe, dadurch skaliert). Panel ohne Slot-Zellen, 4 px Rand.
- Sidebar: ein durchgehender Kasten statt kopierter Kopfleiste mit Seitenstrichen.
- Neu: /cosmetics (/kosmetik) zeigt/waehlt deine Kosmetik.
- Kosmetik-Preise etwa halbiert.
- Neu: Projektil-Trails (Pfeile, Enderperlen) in Duellen.
- Claims (Bau-SMP): /claim oeffnet ein Menue - Chunk claimen (16x16), Mitglieder per Klick (Freunde aus /friend; Rechte: Bauen / Truhen & Tueren), Grenze mit Partikeln (/claim show), Loeschen mit Bestaetigung, Actionbar beim Betreten/Verlassen. Standard-Limit 6.
- Auktionshaus: Suche (/ah search <Text>).
- Chat-Schutz (ChatGuard): Link-Sperre, Caps-Limit, Wortliste, @Name-Ping (config chat.*). Claims: /claim tp <Name>, /claim visitors.
- Kopfgeld (/bounty): Geld auf Spieler setzen, Menue mit Top-Kopfgeldern, Auszahlung beim Toeten (SMP und Bau-SMP getrennt, Gebuehr, Ablauf mit Rueckgabe, Schutz gegen Freunde/Selbst/Wiederholung). Claims: /claim invite mit Annehmen-Button, Besucher-Modus (Tueren/Knoepfe fuer Fremde).
- Events: fertige Vorlagen (/duelladmin event template|templates), Wochenplan (config event-schedule), Tab-Vorschlaege fuer /duelladmin game und event (Vorlagen, Zeiten, Minuten, Kits).
- Teamduelle: /party team [Kit] teilt die Party (gerade Zahl, ab 4) zufaellig in zwei Teams, kein Teamschaden, Team gewinnt wenn das andere ausgeschieden ist. Event-Abmeldung beim Logout (Anmeldung + laufendes Turnier). /gemboost <2-10> [Minuten] | off: Gem-Boost auf Spielzeit-, Daily- und Quest-Gems.
- Duell-Lobby: neue NPCs "ranked" (Mit Elo), "unranked" (Ohne Elo) und "team" (Team-Duelle). Team-Duelle per Warteschlange: Party mit genau 2/3/4 Spielern waehlt Teamgroesse + Kit, wird mit einer gleich grossen Party zusammengefuehrt (/teamduel, /teamduel leave).
- Performance: Claim-Suche per Chunk-Index (find() prueft nur Claims im eigenen Chunk). /notify claim|mention|bounty on|off: persoenliche Benachrichtigungen abschaltbar (prefs.yml).
- Team-Spawns: /duelladmin setduelspawn <Arena> <1|2> [Platz 2-4] legt weitere Spawns pro Team fuer Team-Duelle fest (Platz 1 = Hauptspawn spawn1/spawn2). Spieler eines Teams werden auf die Plaetze verteilt, fehlt einer, nutzen sie den Hauptspawn.
- Admin-Menue (/adminmenu): Spieler (Timeout/Unmute/Kick/Bann mit Shift), Gem-Boost, Event-Vorlagen, Backup, Performance, Config-Pruefung. Spectate: kein Durchfliegen von Bloecken, max. Abstand (watch.max-distance), Actionbar mit Namen und Leben. Duell-NPCs zeigen wartende Spieler/laufende Duelle. Freundesliste zeigt den Ort (Lobby/SMP/Bau-SMP/Duell/Parkour). Discord-Status (webhook.status-minutes).
- Locator-Bar: ausserhalb des SMP komplett aus (waypoint_receive_range 0), im SMP nur das Drachenei (falls vorhanden).
- Neu (SMP/Bau-SMP): Schlaf-Abstimmung (sleep.percent), AFK-Anzeige in der Tab-Liste (afk.minutes), Grabstein (grave.*), persoenliche Markierungen /mark. Duelle: Kampfuebersicht nach dem Tod, Sudden Death (duel.sudden-death-minutes), NPC "dummy" (Trainings-Dummy mit Schaden/DPS). Team: /vanish, /freeze, /invsee, /staffchat (/sc).
- Neu: /timeout <Spieler> [Dauer] [Grund] - Chat-Timeout (Standard 10 Min, config mute.default-timeout-minutes); nutzt das bestehende Mute-System.
- Entfernt: Rohstoff-/Erz-Shop im Gem-Shop. Stattdessen Armor-Trims: Muster + Trim-Materialien in /cosmetics, gelten im Duell auf der Kit-Ruestung.

## Anti-Cheat: Explosionen, Drache und Rückstoß
- Schwere Treffer von Enderdrache, Wither, Warden, Eisengolem, Hoglin, Ravager, Breeze, Ghast-Feuerbällen, Creeper, TNT, End-Kristall u. a. lösen keinen Bewegungsalarm mehr aus (6 bis 9 Sekunden Schutz nach dem Treffer, Drache/Wither am längsten).
- Zusätzliche Schadensarten zählen als Schub: Sonic Boom (Warden), Windstoß, Feuerwerk.
- Neue Sicherheitsgrenze `anticheat.launch-max-move` (Standard 7 Blöcke pro Schritt): Während der Schutzphase darf man kräftig geschleudert werden, ein Sprung wie ein Teleport wird aber trotzdem als Speed gewertet (0 = aus). Elytra, Fahrzeuge, Creative und Lag sind ausgenommen.

# Änderungen 1.1.1

## Gem-Werkzeuge
- **Eile:** Mit Hammer-Spitzhacke, Fäller-Axt oder Hammer-Schaufel in der Hand gibt es Eile II (`gems.haste-level`, 0 = aus). Zusammen mit Effizienz V baut man damit praktisch sofort ab. Der Effekt verschwindet kurz nach dem Wegstecken.
- **Fäller-Axt:** Große Bäume werden in Schüben von 250 Stämmen pro Tick gefällt (kein Ruckeln mehr bei sehr großen Bäumen), die Reihenfolge ist von unten nach oben.
- Anti-Cheat ignoriert weiterhin alle Extra-Blöcke von Hammer, Axt, Schaufel und Vein Miner.

# Änderungen 1.1.0

## Eingearbeitet: deine Änderungen seit V97 (Stand V10.9, Beschreibungen in `docs/aenderungen-v10.9/`)
Bau-SMP mit eigenem Inventar und eigenem Auktionshaus, Kill beendet Combat, Gem-Werkzeuge (neue Schaufel, Zuverlässigkeits-Fix, Admin-Funktionen),
Join ohne Festhalten, Vein Miner im Bau-SMP, Locator-Bar nur mit Drachenei, Bau-Shop, Schaden-Fix/Lobby-Schutz, Anti-Cheat (Fehlalarm-Fixes, /anticheat on|off, Anti-X-Ray),
Drachenei nicht versteckbar, AFK-Schutz fürs Einkommen, Abbau-Effekte/XP, Zonen-Sperre für Teleports und Combat-Flucht.
- Merge-Regeln: Deine Dateien sind die Grundlage, meine früheren Änderungen (async Speichern, Bans, Mutes, Warps, Backups, Audit, Erstell-Assistent, Icons) bleiben erhalten.
- Gem-Werkzeuge: Deine Version (inkl. Schaufel) plus Effizienz V für alle drei, Upgrade älterer Werkzeuge beim Beitritt und im Shop, Baumgrenze 1200 Stämme.
- Texture-Pack: mein Stand (v89, lila Vanilla-Optik, Custom-Icons) bleibt; dein Pack-Ordner `07-texture-pack` wurde nicht übernommen. Die Item-Zuordnung (`ItemSkins.RULES`) ist meine.
- Auktionshaus: dein Zonen-System (SMP/Bau-SMP getrennt) und mein Erstell-Menü arbeiten zusammen.

# Änderungen 1.0.2

## Auktionshaus & Orders per Menü
- **/ah** → „Verkaufen" und **/order** → „Neue Order" öffnen einen Erstell-Assistenten, ganz ohne Befehle:
  Auktionshaus: Item in deinem Inventar anklicken (Linksklick ganzer Stapel, Rechtsklick 1 Stück) → Preis mit +/- Knöpfen → Bestätigen.
  Orders: Item aus dem Inventar oder aus der Item-Liste wählen → Menge → Preis pro Stück → Bestätigen.
  Das Item wird erst beim Bestätigen aus dem Inventar genommen; Abbrechen/Schließen verliert nichts.
  `/ah sell` ohne Preis und `/order create` ohne Angaben öffnen ebenfalls den Assistenten; die Befehle mit Angaben funktionieren weiter.
- Neue Icons: lila Gem (Gem-Shop), Goldmünze (Dein Geld), Stiefel (Parkour), Haus (Home), Preisschild (Angebote), Kiste mit Pfeil (Abholen).
- Sidebar (SMP): Gem- und Münzen-Symbol vor „Gems"/„Geld" für Spieler mit geladenem Pack; ohne Pack bleibt der normale Punkt.
- Pack v89. Gem ist ein lila eingefärbter Smaragd; SMP (Grasblock) und Revanche/Duelle (Eisenschwert) nutzen die Original-Items.

## Duel-Ende
- Neuer dritter Button **Nächster Gegner** (Hotbar-Mitte): verlässt das Duel und stellt dich mit dem gerade gespielten Kit wieder in die Warteschlange (anderer Gegner, keine Revanche). Neue Icons für Revanche (Schwert) und Nächster Gegner.

## Texture-Pack v87 (näher an Vanilla)
- Menü-Hintergründe im Vanilla-Aufbau (Rahmen, Kanten, Slots), aber in Lila passend zum Server.
- Icons im Minecraft-Stil neu gezeichnet (dunkle Kontur, Licht/Schatten): Verlassen (rotes X), Neustart (dicker Kreispfeil), Checkpoint (grüne Fahne), Pokal (Rangliste), Balkendiagramm (Statistik), Party, Pfeile hoch/runter (Gefragt/Im Überfluss), Glühbirne (Tipp), Gem-Werkzeuge; Smaragd und Kompass bleiben Original.
  Übrige Menü-Buttons nutzen echte Vanilla-Items (Eisenschwert, Kompass, Buch ...), die auch ohne geladenes Pack funktionieren.
- Entfernt: eigene Buttons/Tooltip-Rahmen und Block-Texturen (Glas), damit echte Spielblöcke unverändert bleiben.
- Gem-Werkzeuge: Icons fehlten im Pack bisher (Fehler-Textur) - behoben.

# Änderungen 1.0.1

## Gem-Werkzeuge
- **Hammer-Spitzhacke:** Behoben: Nach einem 3x3-Abbau ließ sich mehrere Sekunden lang kaum weiterbauen. Ursache: Der Anti-Cheat
  zählte die neun Abbau-Ereignisse des Hammers als "FastBreak" und brach echte Abbau-Versuche ab (und sammelte dabei Verstöße).
  Die Zusatz-Blöcke der Gem-Werkzeuge zählen jetzt nicht mehr mit.
- **Fäller-Axt:** Große Bäume werden vollständig gefällt (bis 1200 Stämme statt bisher 160; bis 300 Stämme im selben Tick, größere
  in den Folgeticks). Es werden nur Stämme derselben Holzart gefällt, ohne Blätter in der Nähe (Holzhaus) passiert nichts.
- **Effizienz V** statt IV für beide Werkzeuge. Bereits gekaufte Werkzeuge werden beim Beitritt und beim Öffnen des Gem-Shops automatisch angehoben.

## Beitritt
- Neue Spieler werden nicht mehr festgehalten, bis das Texturpack geladen ist (`resourcepack.freeze-on-join: false`, Standard).
  Während des Ladens sind sie nur vor Schaden geschützt. Wartezeit bis zur Freigabe: `hold-seconds` (neuer Standard 8 s).

# Änderungen 1.0.0 (gegenüber V9.6)

## Neu
- **Mutes:** `/mute <Spieler> [Dauer] [Grund]`, `/unmute` – dauerhaft oder zeitlich begrenzt, bleibt nach Neustart bestehen;
  blockiert Chat und private Nachrichten.
- **`/modlog <Spieler>`:** Verlauf von Bans, Kicks und Mutes.
- **Warps und `/back`:** `/warp`, `/warps`, `/setwarp`, `/delwarp`; `/back` zum letzten Ort oder Todesort (SMP, mit Wartezeit und Combat-Schutz).
- **Elo-Wertung** für Duels (`duels.elo-k`), sichtbar in `/duelstats` und im Chat nach dem Duell.
- **`/duelnetwork`** (`reload`, `info`, `backup`, `debug`) – auch von der Konsole nutzbar.
- **`messages.yml`:** Texte der neuen Funktionen sind ohne Neukompilieren anpassbar.
- **Vault** (Economy-Provider) und **PlaceholderAPI** (`%duelnetwork_...%`) als optionale Anbindungen.
- **`audit.log`:** Handelsprotokoll für `/pay`, Auktionshaus-Käufe, große Geldbeträge und Warps.
- Tests für die reine Logik (Dauer-Parser, Gebühren, Elo) und ein GitHub-Actions-Build.

## Sicherheit und Daten
- Owner wird nicht mehr automatisch OP (`ranks.owner-grants-op: false`); Team-Rechte laufen über Permissions, vom Plugin vergebenes OP wird beim Beitritt zurückgenommen.
- Fein abgestufte Rechte: `duelnetwork.ban`, `.kick`, `.unban`, `.rank`, `.reports`, `.mute`, `.modlog`, `.warp` (alle in `duelnetwork.admin` enthalten).
- Automatische **Backups** aller Datendateien (`backup.*`) und `/duelnetwork backup`.
- Config-Version 5; neue Einstellungen werden bei Updates ergänzt, bestehende Werte bleiben erhalten.
- Standard-NPC-Skins sind neutrale MHF-Skins statt echter Spielernamen.

## Performance (aus V9.7)
- Asynchrone, atomare Dateispeicherung (`Store`) statt `saveConfig()`/`save()` im Haupt-Thread; gebündeltes `saveConfig()`.
- RTP lädt Chunks asynchron. Anti-Cheat: günstigere Prüfungen pro Bewegung, zwischengespeicherte Config-/TPS-/Trank-Abfragen.

## Moderation (aus V9.7)
- `/ban <Spieler> [Dauer] <Grund>` mit Dauer, Log und ohne blockierenden Namens-Lookup; Tab-Completion.
- **Bugfix:** Anti-Cheat-Bann kam nie an (lief über einen Konsolenbefehl, den das Plugin ablehnte); jetzt direkt über `Moderation`, Dauer über `anticheat.ban-duration`.
- **Bugfix:** `/unban` bereinigte nur die alte Namensliste; jetzt auch die Profil-Bannliste.

## Wirtschaft (aus V9.7)
- Auktionshaus: Rest-Items gehen in `/ah claim`, Meldung für Offline-Verkäufer, optionale Gebühr `ah.tax-percent`.
- Kontostände überlaufsicher; Admin-`/pay` wird protokolliert.

## Texturpack-Server (aus V9.7)
- Nur GET/HEAD, höchstens 12 Anfragen/Minute und Adresse, eigener Thread-Pool, IP-Ermittlung abschaltbar (`resourcepack.detect-ip`).

## Fehler-Logging (aus V9.7)
- Bisher verschluckte Fehler werden gemeldet (gedrosselt, Details mit `debug: true`).

## Nicht Teil von 1.0
- Aufteilung von `DuelNetworkPlugin` in Module und Auslagerung *aller* Texte in `messages.yml` (nur die neuen Funktionen sind ausgelagert).
- Datenbank (SQLite/MySQL) statt YAML, Claims/Land-Schutz.


## Stabilität und Performance (aktueller Build)
- Nach jedem Login startet der Spieler in der Hauptlobby – auch nach einem Serverneustart; SMP- und Bau-SMP-Inventare werden beim Logout weiterhin getrennt gespeichert.
- Arena-Snapshots werden für normale und Party-Duelle in konfigurierbaren Batches pro Tick erstellt; keine feste Arena-Größenobergrenze, nur arithmetischer Overflow wird abgelehnt.
- Arena-Reset-Fehler halten die Arena gesperrt, statt einen unvollständigen Reset als erfolgreich freizugeben.
- Duell-Einladungen werden bei Quit, Ablehnung, Abbruch und Timeout beidseitig bereinigt. Duel-Kits werden beim Logout nicht als normales Profilinventar gesichert.
- Backup-Archive enthalten YAML und konsistente SQLite-Snapshots, werden gegen unsichere ZIP-Pfade geprüft und erhalten ein Manifest. Restore erfordert `confirm`, erstellt eine Rückfallkopie und wird beim nächsten Serverstart angewendet.
- `/duelladmin diagnose` prüft Setup-Daten, ohne Chunk- oder Block-Scans. Statistik-Ergebnisse werden vor Nebenwirkungen dedupliziert; Ranglistenlimits sind begrenzt.


- **Nether/End kontrolliert öffnen:** `/duelladmin unlock start <nether|end> [24h]` plant eine Freischaltung mit persistentem Countdown und gestaffelten Restzeitmeldungen nur an Spieler im normalen SMP; `/duelladmin unlock status` zeigt den Stand, `unlock <dimension>` öffnet sofort und `lock <dimension>` sperrt.
- **Enderdrachen-Sperre:** End-RTP und Portale ins End bleiben bis zum besiegten Enderdrachen blockiert, auch wenn der Countdown abgelaufen ist. Die Rückreise aus einer gesperrten Dimension bleibt möglich. Nether/End-RTP und Portale sind nur im normalen SMP nutzbar.
- **Duell-/Event-Lobby-Hotbars:** Duell-Lobby bietet Navigator, Party und Duell-Kit-Auswahl; Event-Lobby (per `setlobby events`) bietet Event-Menü, Navigator und Party. Der Events-NPC/Navigator teleportiert in die konfigurierte Event-Lobby, falls gesetzt.
- **Trainingsdummy:** Dummy-NPCs nehmen sichtbaren echten Schaden, zeigen Treffer/Schaden/DPS und können nicht getötet werden. In Dummy-Nähe erhalten Spieler ein unzerstörbares Diamantschwert und eine Diamantaxt; temporäre Trainingswaffen werden beim Verlassen entfernt und nicht gespeichert.

- **Dummy-Treffer im Survival:** Der Lobby-PvP-Schutz lässt Angriffe auf den Trainingsdummy durch, schützt andere Spieler aber weiterhin. Die Actionbar zeigt jetzt den tatsächlich berechneten Treffer-Schaden in HP und Herzen, Trefferzahl, Gesamtschaden und DPS; abgebrochene Treffer werden nicht gezählt.
