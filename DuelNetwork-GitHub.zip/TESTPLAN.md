# Testplan vor dem Livebetrieb

Auf einem Testserver (Paper 1.21.x) mit mindestens zwei Spielern durchgehen. Haken setzen, Auffälligkeiten notieren.

## Start und Daten
- [ ] Server startet ohne Fehler/Warnungen von DuelNetwork; `messages.yml` und `config.yml` entstehen.
- [ ] `/duelnetwork info` zeigt Version 1.2.1; `/duelnetwork backup` erzeugt eine ZIP in `plugins/DuelNetwork/backups`.
- [ ] Nach Migration enthält `economy.db` die Konten aus `economy.yml`; ein Neustart verändert keine Kontostände.
- [ ] Eine wiederholte Ledger-Transaktions-ID erzeugt keine doppelte Gutschrift.
- [ ] Ein künstlicher `PENDING`-Journal-Eintrag wird beim nächsten Start fortgesetzt und auf `COMMITTED` gesetzt.
- [ ] Geld geben, Server mit `stop` beenden, neu starten: Kontostand ist erhalten.
- [ ] Beim Start wird `claims.db` mit Schema-Version 1 angelegt; ein Neustart erhält Claims und Rollen.
- [ ] `/claim create haus 8` erstellt im Bau-SMP einen Claim; normales PvP-SMP, Lobby, Duell und Parkour lehnen die Erstellung ab.
- [ ] Im normalen PvP-SMP bleiben Bauen, Container und PvP unabhängig von Claims unverändert.
- [ ] Überlappende Claims, Claims über `claims.max-area` oder mehr als `claims.max-per-player` Claims werden abgelehnt.
- [ ] `/claim info` und `/claim list` zeigen Claim-ID, Grenzen und Besitzer; `/claim delete` funktioniert nur für Besitzer oder Claim-Admin.
- [ ] `trust` erlaubt Türen, Redstone und Container; `member` erlaubt zusätzlich Bauen und Abbauen; Fremde werden geblockt.
- [ ] Truhen, Türen, Item-Frames, Rüstungsständer, Flüssigkeiten, Explosionen, Pistons und Mob-Blockänderungen können Claims nicht umgehen.
- [ ] Hammer, Baumfällen und Vein Miner bauen an Claimgrenzen nur erlaubte Blöcke ab.
- [ ] `duelnetwork.claim.bypass` kann Claim-Schutz umgehen; ohne Permission ist Creative kein automatischer Claim-Bypass.
- [ ] `/duelnetwork reload` nach einer Änderung in `messages.yml` übernimmt den neuen Text.

## Moderation
- [ ] `/ban Spieler 1m Test`: Spieler fliegt raus, nach 1 Minute kann er wieder beitreten. Eintrag in `moderation.log`.
- [ ] `/ban Spieler Test` (dauerhaft), dann `/unban Spieler`: Spieler kann wieder beitreten.
- [ ] Owner/Admin lässt sich nicht bannen, kicken oder stummschalten.
- [ ] `/mute Spieler 2m`: Chat und `/msg` blockiert, nach 2 Minuten wieder frei; `/unmute` wirkt sofort. Nach Neustart bleibt der Mute bestehen.
- [ ] `/modlog Spieler` zeigt die Einträge.
- [ ] Nicht-OP mit Rang Admin: `/ban`, `/kick`, `/mute` funktionieren; Owner ohne OP: `/gamemode`, `/give` funktionieren.

## Wirtschaft
- [ ] `/pay` zwischen zwei Spielern: Beträge stimmen; Eintrag in `audit.log`.
- [ ] Auktionshaus: Angebot einstellen, kaufen, zurückholen, Ablauf; bei vollem Inventar landet der Rest in `/ah claim`.
- [ ] Verkäufer offline: Meldung beim nächsten Beitritt. Mit `ah.tax-percent: 10` erhält der Verkäufer 90 %.
- [ ] Doppelklick auf "Kaufen" kauft nicht zweimal.
- [ ] Mit Vault + Essentials-Chat o. Ä.: Kontostand stimmt überein; mit PlaceholderAPI: `/papi parse me %duelnetwork_money%`.

## SMP / Teleports
- [ ] Gems: Onlinezeit zählt in Lobby, SMP, Bau-SMP, Duell/Event/Parkour und auch während AFK; nach jeweils 10 Online-Minuten gibt es 1 Gem, Offlinezeit zählt nicht.
- [ ] `/shop`: in einer mehrseitigen Kategorie mehrfach auf „Nächste Seite“ klicken; Seitenindex, Inventartitel und Artikel wechseln bis zum Ende; Vorherige/Erste/Letzte und Shift-Klick prüfen. Dasselbe im Bau-SMP-Shop.
- [ ] Homes: vorhandene gemeinsame Homes werden ins normale SMP übernommen; danach `/sethome` im Bau-SMP erstellt dort eine getrennte Liste. Wechsel zwischen den Modi zeigt jeweils nur die Homes des aktuellen Modus; Spieler ohne Rang haben 3 pro Modus.
- [ ] `/rtp` (Overworld, Nether, End): kein Server-Ruckeln, sicherer Ort; Bewegen bricht den Countdown ab.
- [ ] `/setwarp test`, `/warp test` (mit Wartezeit), `/warps`, `/delwarp test`.
- [ ] `/back` nach Teleport und nach Tod (im SMP); in der Lobby funktioniert es nicht.

## Duels / Anti-Cheat
- [ ] `/duel <Spieler>`: Herausforderer kann vor der Annahme ein Kit auswählen, ohne in die Zufallswarteschlange oder „beschäftigt“-Meldung zu geraten; nach Annahme wählt der Gegner dasselbe Kit und das Duell startet.
- [ ] Duell bis zum Ende: Statistik und Elo ändern sich bei beiden Spielern.
- [ ] Kleine Arena und Arena mit mehr als 100.000 Resetblöcken: bei gesetzten `pos1`, `pos2`, `spawn1`, `spawn2` in derselben Welt zeigt `/duelladmin arena check` `OK`; Duell startet und setzt die Arena zurück.
- [ ] Anti-Cheat: normales Spielen (Sprinten, Elytra, Windcharge, Boot, Wasser, Leiter) löst **keine** Warnungen aus (`/anticheat alerts`).
- [ ] Unter künstlichem Lag (z. B. `/tick rate 10`) gibt es keine Strafen.
- [ ] Bei gesperrtem Nether/End funktioniert `/rtp nether` bzw. `/rtp end` nicht.
- [ ] Bei gesperrtem Nether/End funktioniert `/rtp` auch innerhalb der jeweiligen Welt nicht.
- [ ] Nether-/End-Portale werden bei gesperrter Dimension in beide Richtungen abgebrochen; nach `unlock` funktionieren sie wieder.
- [ ] Resourcepack-Version 92 lädt; die Gem-Textur ist dunkler und bleibt pixelig/Vanilla-nah.

## Texturpack
- [ ] Pack wird geladen (oder `/texturen an` im manuellen Modus); Download-Port erreichbar; mehr als 12 Downloads/Minute von einer Adresse werden abgelehnt.

## 1.3.0 – zusätzliche Tests
- Server ohne Texturpack starten: kein Pack-Download beim Join, Menüs und Sidebar normal lesbar.
- Verkaufen-Menü: Smaragd-Button, Auszahlung korrekt.
- Best of 3: Runden, Reset, Zwischenstand, Serienende, Revanche, `/leave` mitten in der Serie.
- `/board add elo` / `money` / `parkour <Map>`: erscheint, aktualisiert sich, bleibt nach Neustart; `/board remove`.
- `/spectate` aus der Lobby: Zuschauen, automatische Rückkehr nach Duellende, Quit während des Zuschauens.
- `/duel history` nach einigen Duellen; `/dnwartung perf`.
- Geld getrennt: SMP vs. Bau-SMP, `/pay` im Bau-SMP, Auktionshaus/Orders je Modus.

## 1.3.1 – Leaderboard
- Pack annehmen: Logo oben über dem Leaderboard, Hintergrund transparent.
- Genau ein Rahmen außen; keine Linien/Füllungen/Unterstreichungen zwischen den Zeilen.
- Gems (lila) und Geld-Icon korrekt, 1-px-Versatz prüfen (Logo-Höhe/Breite in pack-gen.py anpassbar).
- Pack ablehnen: normale Sidebar mit ◆ / ● ohne Logo, nichts kaputt.
- Buttons: Escape-Menü/Optionen lila-schwarz, Hover heller, deaktivierte Buttons dunkelgrau.
- Plugin-Menü (z. B. /spectate, Verkaufen): lila Hintergrund nur oben (Spielerinventar unten bleibt Vanilla), deckungsgleich mit den Slots, Items sichtbar über dem Hintergrund, Titeltext an gewohnter Stelle.
- Normale Truhe/Fass: unverändert. Spieler ohne Pack: Menüs wie vorher.
- Falls Hintergrund 1 px verschoben: `ascent` (13) bzw. Zeichen-Rückschritt in pack-gen.py anpassen.

## 1.4.0
- Gem-Shop: keine Schaufel, kein Admin-Button; Kosmetik und Rohstoffe öffnen sich; Kauf zieht Gems ab (auch bei zu wenig Gems: Fehlermeldung).
- Trim kaufen, Muster + Material wählen → Duell starten: Rüstung trägt den Trim. Schalter „aus“ → kein Trim. Partyduell prüfen.
- Kill-Effekt wählen, Duell gewinnen → Effekt am Verlierer (nur alle 4 s).
- Rohstoffe: im Lobby-Modus verweigert, im SMP gekauft.
- Freunde: add/accept, Menü-Klicks (TP-Anfrage, Duell, Party), Join-Meldung, remove.
- Handel: zwei Spieler SMP; Items rein, Geld per /trade money, beide bestätigen → getauscht. Test Abbruch (Schließen), volles Inventar, Änderung nach Bestätigung (Bestätigung weg), Shift-Klick aus dem Inventar.
- Season: `/season`, `/season end` (Admin) → Belohnungen und Elo-Reset prüfen.
- Parkour: zwei Läufe, zweiter zeigt Geist(er) (TextDisplay + Partikel), Abbruch/Neustart entfernt sie.
- Webhook: URL setzen, Test-Report (/report) kommt in Discord an.

## 1.5.0
- `/dnwartung perf`: Liste der Plugin-Tasks erscheint und füllt sich nach ein paar Minuten; Cleanup-Zeile sichtbar.
- Cleanup: 100 Items in einen Chunk werfen → nach ≤60 s bleiben ca. 60; benannte/zahme Tiere und Pferde bleiben.
- `/stats`, `/stats <Spieler>`: Werte stimmen mit `/duelstats` überein.
- `/ranked`: Casual einschalten, Duell spielen → Elo unverändert, Meldung „Casual“; zurück auf Ranked.
- `/tutorial`: Seiten blättern; neuer Spieler (neue UUID) bekommt Hinweis nach 5 s.

## 1.6.0
- `messages.yml` enthält neue Einträge `friends.*`, `trade.*`, `cosmetics.*`, `season.*`; Text ändern, `/duelnetwork reload`, Wirkung prüfen.
- Handel abschließen → Zeile in `plugins/DuelNetwork/trades.log`.
- Kosmetik → Kill-Effekte: 7 Effekte + „Kein Effekt“ (Slot 24) klickbar; nach `/season end` hat der Erste die Champion-Aura (Slot 19).

## 1.6.1
- `/tpahere <Spieler>` (SMP): Spieler A fragt, Spieler B nimmt mit `/tpa accept` an und teleportiert sich zu A (nach der Verzögerung). Ablehnen mit `/tpa deny`; im Combat gesperrt; Bau-SMP und SMP getrennt prüfen.

## 1.7.0
- `/tpatoggle` aus → `/tpa` und `/tpahere` auf diesen Spieler melden „nimmt keine Anfragen an“; wieder an → geht.
- `/pc` in einer Party, `/fc` mit Freunden online; gemutet → blockiert.
- `/friend notify` aus → keine Join-/Quit-Meldungen der Freunde mehr.
- `/msg` → Ton beim Empfänger.
- Duell spielen → nach dem Ergebnis Zusammenfassung bei beiden; danach `/stats` → Kit-Statistik gefüllt.
- Neustart: `restart.enabled: true`, `restart.at` 2 Minuten in der Zukunft setzen, `/duelnetwork reload`?? (Neustart der Zeitschaltuhr braucht einen Serverneustart); Ansagen und sauberes Herunterfahren prüfen.

## 1.7.1
- /gems im SMP: nur Spitzhacke, Axt (und Rohstoffe). /gems in Lobby: Kosmetik + Rohstoffe, keine Werkzeuge.
- Axt kaufen, Kosmetik oeffnen, Rohstoffe oeffnen, Zurueck: man bleibt im Gem-Shop und kommt nie in den normalen Shop.
- Normalen Shop (NPC/Verkaufen) pruefen: funktioniert weiter.

## 1.8.0
- Menue-Hintergrund: Items sitzen mittig in den Slots (3/6 Reihen), keine Verschiebung nach links.
- Sidebar: ein Kasten, keine seitlichen Striche unter der Kopfleiste; mit 3..15 Zeilen testen.
- /cosmetics oeffnet Menue (auch in der Lobby); Trails waehlen, im Duell Pfeil/Enderperle werfen -> Partikelspur.
- /claim im Bau-SMP: Chunk claimen, Freund anklicken (keine -> Bauen -> Truhen&Tueren -> keine), /claim show zeigt Rand, Betreten zeigt Actionbar, Loeschen braucht zwei Klicks. Im normalen SMP: keine Claims.
- /ah search diamond filtert; /ah search ohne Text setzt zurueck.
- Chat: Link senden (blockiert), NUR GROSSBUCHSTABEN (wird klein), @Name (Ping), filter-words in config testen; Team (duelnetwork.admin) ist ausgenommen.
- /claim tp <Name> und /claim visitors im Bau-SMP.
- /bounty set <Spieler> 1k: Geld abgezogen (Gebuehr 10%), Broadcast; Spieler toeten -> Auszahlung; Freund/Spender/Wiederholung -> keine; /bounty zeigt Menue; nach 7 Tagen Rueckgabe.
- /claim invite <Spieler>: Buttons beim Empfaenger, /claim accept; Besucher-Modus im Menue: Fremde nutzen Tueren/Knoepfe, aber keine Kisten.
- /duelladmin event templates; event template ffa-abend (startet sofort) bzw. mit "heute 20:00"; event-schedule ["FRIDAY 20:00 ffa-abend"] legt 2 h vorher das Event an; Tab-Vorschlaege bei /duelladmin game ffa <Kit> <Minuten> und event game/quick/add/time.
- /party team <Kit> mit 4 Spielern: Teams, Spawns (Team1 spawn1, Team2 spawn2), kein Teamschaden, Ende wenn ein Team komplett ausgeschieden ist; mit 3 Spielern Fehlermeldung.
- Event-Anmeldung, dann ausloggen: Teilnehmerzahl sinkt; laufendes Turnier: nicht gestartetes Match kampflos gewertet.
- /gemboost 5 60: Broadcast/Title, SMP-Gem-Tick gibt 5 (Meldung mit Boost), /daily und Quest-Gems x5; Erinnerung bei 10 und 1 Min, Ende-Meldung; /gemboost off; /gemboost ohne Argument = Status.
- Duell-Lobby: /duelladmin npc ranked | unranked | team an die Duell-Lobby stellen. Ranked-NPC: Elo zaehlt, Unranked-NPC: Casual; Kit-Menue oeffnet sich. Team-NPC: Party mit 2/3/4 Spielern anmelden, zweite Party gleicher Groesse+Kit -> Match startet (Team 1 = zuerst wartende Party), kein Teamschaden, Ende bei komplett ausgeschiedenem Team; /teamduel leave.
- Claim-Index: viele Claims anlegen/loeschen, Bauen/Interagieren an Claim-Grenzen (Chunk-Rand) und in mehrchunkigen Claims pruefen; /dnwartung perf zeigt Tasks. /notify claim off -> keine Actionbar mehr; mention/bounty analog.
- Team-Spawns: setduelspawn <Arena> 1 2 / 2 2 usw. setzen, 2v2/4v4 starten: Teamkollegen erscheinen auf verschiedenen Plaetzen; ohne Zusatzspawns alle am Hauptspawn. Tab-Vorschlaege bei /duelladmin setduelspawn.
- /adminmenu: Spielerliste, Timeout/Unmute/Kick, Bann nur mit Shift-Klick, Boost- und Event-Buttons, Backup/Perf/Config.
- Spectate: Zuschauer kommen nicht durch Waende, Abstand-Grenze (40), Actionbar mit Leben beider Kaempfer.
- Duell-NPCs: Name zeigt "(N warten • M laufen)" (Team-NPC: Teams); Freundesliste zeigt Ort; webhook.status-minutes + "status" in webhook.events.
- Locator-Bar: in Lobby, Duell, Bau-SMP keine Punkte; im SMP nur das Drachenei (Traeger oder Marker), ohne Ei leer; Spieler untereinander nie sichtbar. Falls der Server das Attribut nicht kennt, steht eine Warnung im Log.
- Schlaf: 30% der aktiven Spieler im Bett -> Tag; AFK zaehlt nicht. AFK: 5 Min stehen -> [AFK] in Tab, Bewegung hebt auf.
- Grabstein: im SMP/Bau-SMP sterben -> Kiste am Todesort (2. Kiste darueber bei >27 Items), 5 Min nur Besitzer, nach 30 Min Items fallen; leere Kiste verschwindet; im Duell kein Grabstein.
- /mark set base, /mark base (Actionbar mit Pfeil/Entfernung), /mark del, Limit 5, getrennt SMP/Bau.
- Duell: Kampfuebersicht nach Tod (nur wenn beide kaempften), Sudden Death nach 5 Min, /duelladmin npc dummy -> Schlaege zeigen Schaden/DPS (falls keine Anzeige: Treffer an Invulnerable-NPCs ggf. nicht als Event, melden).
- Team: /vanish, /freeze <Spieler>, /invsee <Spieler>, /sc.

## Tag/Nacht & Schlafen (eine Welt)
- [ ] In Lobby/Duell/Event/Parkour ist immer Mittag, klares Wetter.
- [ ] SMP: Nacht per Schlafen überspringen -> Bau-Spieler sehen ihre Uhr unverändert.
- [ ] Bau-SMP nachts: Bett-Rechtsklick -> Actionbar x/y, ab Anteil wird es Morgen nur im Bau.
- [ ] Bau tagsüber: Bett meldet "nur nachts".
- [ ] Moduswechsel SMP <-> Bau wechselt die Anzeige innerhalb ~1 s.
- [ ] Schlafen: aufstehen aktualisiert x/y; Nachtsprung läuft ~1,5 s als Zeitraffer; steht jemand in der Wartezeit auf, bleibt es Nacht.
- [ ] Schlaf-Bossbar erscheint nur für SMP bzw. Bau-Spieler und verschwindet nach dem Sprung.
- [ ] Allein online: Nacht wird nach <1 s übersprungen; Regeneration nach dem Schlafen.
- [ ] `sleep.reward-gems: 5` zahlt nur Mitschläfern.
- [ ] `sleep.percent: 500` in der config -> Hinweis in Konsole und bei `/duelnetwork reload`.
- [ ] `/duelnetwork info` zeigt Modi, Welten, Fehleranzahl, Config-Status.
- [ ] In einer Party: Sidebar in Lobby/SMP zeigt "Party: x online"; ohne Party keine Zeile.
- [ ] Neuer Spieler: je Modus genau einmal ein Hinweis (`hints.enabled`).
- [ ] `/duelnetwork matches` zeigt Zahlen, die zur Lage passen.
- [ ] Nach 2+ gewerteten Duellen: Elo-Verlauf in der Duell-Historie.
- [ ] Webhook `event` in `webhook.events`: Start und Sieger kommen in Discord an.
- [ ] `/settings`: Schalter wirken (z. B. Hinweise aus -> keine Modus-Hinweise).
- [ ] Tippfehler `/duell` -> "Meintest du /duel?".
- [ ] `/duelnetwork maintenance on`: neue Duelle/Team-Matches werden abgelehnt, laufende enden normal.
- [ ] `/duelnetwork report` erzeugt `fehlerbericht.txt`.
- [ ] Navigator-Duelle sowie Rechts- und Linksklick auf den Duell-NPC führen zur konfigurierten Duell-Lobby; ohne Lobby erscheint ein Setup-Hinweis statt Kit-Auswahl.
- [ ] `/goals`, `/quests` und Alias `/aufgaben` sind nicht registriert; `/daily` funktioniert weiterhin.
- [ ] Nach 1v1-Duell erscheint die Zusammenfassung (nicht im Party-Match).
- [ ] Tod im SMP: Klick auf [Koordinaten kopieren] kopiert in die Zwischenablage.
- [ ] Lag-Warnung: `lag.warn-tps: 19.9` testweise -> Admin-Meldung nach ~1,5 Min.
- [ ] SMP: Items mit Wert-Zeile aufheben -> landen sofort im vorhandenen Stapel (Holz, Stein, Erde ...).
- [ ] `/share Haus` -> Freund bekommt Klick-Teleport; Fremde/anderer Modus werden abgelehnt.
- [ ] `/claim map` zeigt Farben richtig; `/gems history` zeigt Herkunft; `/duel last` reiht ins letzte Kit ein.
- [ ] Alte config.yml ohne neue Abschnitte -> Hinweis "neue Einstellungen fehlen".
- [ ] SMP: Item aufheben, das schon einen Stapel hat -> landet direkt auf dem Stapel; selbst geteilte Stapel bleiben getrennt; aus Kiste nehmen ändert nichts.
- [ ] `/duelladmin setlobby duell` setzen; Duelle-NPC und Kompass->Duelle teleportieren dorthin; dort Ranked/Unranked/Teams-NPCs funktionieren.
- [ ] `/gems` in der Lobby öffnet den Shop mit Kosmetik; im SMP mit Spitzhacke/Axt; `/cosmetics` überall.
- [ ] Shop: blättern (auch Shift = 5 Seiten, Erste/Letzte), letzte Seite ohne "Nächste", Kaufen ohne Mauszeiger-Reset; Bau-Shop genauso.
- [ ] Kosmetik: alle neuen Muster/Effekte/Spuren kaufbar, auswählbar, Partikel erscheinen; 36er-Menüs sehen im Pack richtig aus.
- [ ] Spuren-Menü: Umschalter Pfeile/Enderperlen; Perle zeigt ihre eigene Spur lückenlos, Pfeil seine; nach "Keine Spur" für Perlen bleibt die Pfeil-Spur.


## Diagnose-, Backup- und Duell-Regressionen
- [ ] `/duelladmin diagnose` zeigt fehlende/ungültige Spawns, nicht geladene Welten, Arena- und Kit-Status sowie Config-Hinweise; Durchführung lädt oder scannt keine Chunks.
- [ ] Einladung: `/duel <Spieler>`, Herausforderer wählt Kit, Ziel lehnt ab oder verlässt den Server; Herausforderer kann sofort erneut einladen.
- [ ] Einladung läuft nach 60 Sekunden ab; beide Richtungen, ausgewähltes Kit und Host-Zustand sind freigegeben.
- [ ] Aktives Duell: Spieler mit normalen Lobby-Items loggt aus; nach Forfeit und erneutem Join sind die normalen Items vorhanden, nicht das Duel-Kit.
- [ ] Duellstart bei Wartungsmodus/fehlender Arena/Snapshotfehler lässt keine Partner- oder Best-of-Zustände zurück.
- [ ] Arena-Reset gezielt mit Testwelt/Fehlerfall scheitern lassen: Arena bleibt gesperrt und wird nicht als erfolgreich zurückgesetzt freigegeben.
- [ ] Nach einem Duell ist der Ergebnis-Handler doppelt aufrufbar, ohne doppelte Event-/Social-/Kill-Effekt-Seiteneffekte oder Statistik.
- [ ] `/duelnetwork backup` enthält YAML, `economy.db` und die konfigurierte Claims-Datenbank; `/dnwartung backuptest` meldet parsebare YAML und `integrity_check` = ok.
- [ ] Restore auf einer Testkopie: erst ohne `confirm` nur Sicherheitsabfrage; nach Bestätigung Sicherheits-Backup und Marker prüfen; erst beim nächsten Serverstart werden ausgewählte Dateien ersetzt.
- [ ] Backup während regulärer Last: Archivkomprimierung läuft asynchron; kein regelmäßiger Chunk-/Block-Scan; prüfen, dass Server-TPS nicht durch Backup-IO sinken.
- [ ] Aus SMP und Bau-SMP ausloggen, erneut joinen: Spieler erscheint in der Hauptlobby mit Lobby-Inventar; SMP- und Bau-SMP-Inventare/Home-Daten bleiben separat und sind nach bewusstem Wechsel weiterhin vorhanden.
- [ ] Server ordentlich herunterfahren, Plugin/Server wieder starten und joinen: Spieler startet ebenfalls in der Hauptlobby; es wird kein SMP-/Bau-Profil automatisch wieder aktiviert.


## Dimension-Countdowns und Lobby-Training
- [ ] `/duelladmin unlock start nether 1m`: nur normale SMP-Spieler erhalten die Start-/Restzeitmeldungen; Lobby, Duel, Bau-SMP und Event erhalten keine Broadcasts.
- [ ] Countdown über `/duelladmin unlock status` prüfen; Server während des Countdowns neu starten: Zeitpunkt bleibt erhalten, nach Ablauf ist Nether offen.
- [ ] Vor dem Öffnen kein Nether-RTP/Portal hinein; Rückreise aus bereits betretenem Nether zur Overworld bleibt möglich. Nach Öffnung funktionieren `/rtp nether` und Portale nur im normalen SMP.
- [ ] `/duelladmin unlock start end 1m`: Ablauf öffnet das End nicht, solange der Drache lebt; `/rtp end` und Portal hinein bleiben gesperrt. Nach Drachen-Kill werden End-RTP und Portalzugang aktiviert und einmalig gemeldet.
- [ ] `/duelladmin unlock end` ohne Drachen-Kill: End bleibt weiterhin gesperrt; `/duelladmin lock end` bricht den Countdown ab.
- [ ] In der Duell-Lobby `/duelladmin setlobby duell` und `/duelladmin npc dummy`: Navigator-, Party- und Duell-Kit-Hotbar erscheinen; in Dummy-Nähe erscheinen Diamantschwert und Diamantaxt.
- [ ] Mit Schwert/Axt Dummy treffen: sichtbare Trefferreaktion, echte abgezogene Dummy-Lebenspunkte und Actionbar mit Treffer/Schaden/DPS; Dummy kann nicht getötet oder entfernt werden.
- [ ] Im Survival-Modus den Dummy in der geschützten Lobby schlagen: Treffer wird nicht vom Lobby-PvP-Schutz blockiert; Anzeige zeigt echten Schaden in HP/Herzen, Trefferzahl, Gesamtschaden und DPS. Treffer auf andere Spieler bleiben weiterhin blockiert.
- [ ] Dummy-Bereich verlassen: Trainingswaffen werden entfernt und zuvor verdrängte Items bleiben im Inventar; Trainingswaffen werden beim Logout/Profilwechsel nicht dauerhaft gespeichert.
- [ ] `/duelladmin setlobby events`: Event-NPC und Navigator teleportieren in die Event-Lobby; Hotbar zeigt Event-Menü, Navigator und Party. Ohne gesetzte Lobby öffnet Events weiterhin das Termin-Menü.

## 1.8.3 – XP & Ranked
- SMP-XP sammeln, in Bau-SMP wechseln: Level ist dort separat; zurück ins SMP: altes Level.
- Lobby/Duell/Parkour/Event: keine XP, Level 0.
- Zwei Spieler: einer Ranked, einer Unranked in dasselbe Kit → kein Match. Beide Ranked → Match, Elo-Änderung nur für dieses Kit.
- Kit-Menü Ranked: „Deine Elo“ sichtbar; Unranked: nicht.
- Zwei Ranked-Spieler mit großem Elo-Unterschied: Match erst nach wachsender Wartezeit.
