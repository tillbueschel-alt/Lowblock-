# Befehlsübersicht

Automatisch aus `plugin.yml` erzeugt.

| Befehl | Beschreibung | Aliase | Recht |
|---|---|---|---|
| `/navigator` | Oeffnet den Netzwerk-Navigator. | nav, menu |  |
| `/duel [Spieler\|accept\|deny\|cancel\|leave]` | Fordert einen Spieler zum Duel heraus oder oeffnet das Duel-Menue. |  |  |
| `/lobby` | Wechselt zum Lobby-Inventar. |  |  |
| `/smp` | Wechselt zum SMP-Inventar und teleportiert zum SMP-Spawn. |  |  |
| `/events` | Öffnet den Event-Plan (laufende und kommende Events). |  |  |
| `/parkour [help\|list\|join <Map>\|restart\|leave\|records [Map]]` | Parkour-Lobby, Maps, Checkpoints und Zeitläufe. |  |  |
| `/bausmp` | Betritt das Bau-SMP (frei bauen im Survival, kein PvP, Inventar bleibt). | bau, creative, bsmp |  |
| `/combat` | Zeigt den aktuellen SMP-Combat-Status. |  |  |
| `/home` | Öffnet, setzt, nutzt und löscht frei benennbare SMP-Homes. |  |  |
| `/sethome` | Setzt ein SMP-Home. |  |  |
| `/delhome` | Löscht ein SMP-Home. |  |  |
| `/tpa [Spieler\|accept\|deny\|cancel]` | SMP-Teleportanfragen mit Verzögerung. |  |  |
| `/tpahere <Spieler>` | Bittet einen SMP-Spieler, sich zu dir zu teleportieren. |  |  |
| `/tpatoggle` | Teleport-Anfragen (/tpa, /tpahere) ein- oder ausschalten. |  |  |
| `/pc <Nachricht>` | Nachricht an deine Party. | partychat |  |
| `/fc <Nachricht>` | Nachricht an alle Online-Freunde. | friendchat |  |
| `/party [create\|invite\|accept\|deny\|leave\|list\|kick\|promote\|disband\|duel\|ffa\|help]` | Party-Menue, Einladungen, Party-1v1 und Party-FFA. | gruppe |  |
| `/kit` | Admin-Kitvorschau und Kit-Ausrüstung. |  | duelnetwork.admin |
| `/ban <Spieler> [Dauer z. B. 7d] <Grund>` | Bannt einen Spieler (optional zeitlich begrenzt) mit verpflichtendem Grund. |  | duelnetwork.ban |
| `/kick <Spieler> [Grund]` | Kickt einen Spieler. |  | duelnetwork.kick |
| `/unban <Spieler>` | Entbannt einen Spieler. |  | duelnetwork.unban |
| `/rank <Spieler> <Media\|Owner\|Admin\|Premium\|Tester\|reset>` | Setzt oder entfernt einen sichtbaren Serverrang. |  | duelnetwork.rank |
| `/duelstats [Spieler\|top [kills\|tode\|quote] [chat]]` | Zeigt Duel-Statistiken (Siege, Niederlagen, Siegesserie). | dstats |  |
| `/rangliste [kills\|tode\|quote\|parkour]` | Oeffnet das Ranglisten-Menue (Duel Kills/Tode/Quote und Parkour-Rekorde). | ranking, top, bestenliste, leaderboard |  |
| `/msg <Spieler> <Nachricht>` | Private Nachricht an einen Spieler. | m, tell, w, whisper |  |
| `/r <Nachricht>` | Antwortet dem letzten Nachrichten-Partner. | reply |  |
| `/ignore <Spieler\|list>` | Spieler ignorieren / Ignorierliste. |  |  |
| `/ping [Spieler]` | Zeigt deinen Ping oder den eines Spielers. |  |  |
| `/report <Spieler> <Grund>` | Meldet einen Spieler dem Team. |  |  |
| `/reports [clear]` | Zeigt die letzten Spieler-Meldungen (Team). |  | duelnetwork.reports |
| `/anticheat [on\|off\|alerts\|info\|alts\|top\|log\|reset\|xray]` | Anti-Cheat-Verwaltung (Warnungen, Verstoesse, Zweitaccounts). | ac | duelnetwork.admin |
| `/duelladmin` | Admin-Befehle fuer das Duel-System. | dueladmin, mgadmin | duelnetwork.admin |
| `/money [Spieler]` | Zeigt dein Geld und deinen Rang. | bal, balance |  |
| `/pay <Spieler> <Betrag>` | Sendet Geld an einen Spieler. |  |  |
| `/baltop` | Die reichsten Spieler. | balancetop |  |
| `/gems` | Gem-Shop und Gem-Kontostand. | gem, gemshop |  |
| `/sell [hand\|all]` | Verkaufsmenue - Items hineinlegen und Geld bekommen. | sale |  |
| `/shop` | Der Server-Shop (Essen, Kampf, Material, Bloecke, Werkzeug). |  |  |
| `/ah [sell [Preis]\|mine\|claim]` | Auktionshaus - Items verkaufen und kaufen. | auction, auctionhouse |  |
| `/order [create [Item Menge Preis]\|mine\|collect]` | Orders - Items bestellen und Bestellungen beliefern. | orders |  |
| `/rtp [overworld\|nether\|end]` | Zufaellige Position in Overworld, Nether oder End. | wild |  |
| `/market` | Marktpreise - was gerade gefragt oder billig ist. | markt, preise |  |
| `/worth` | Zeigt den Wert des Items in deiner Hand. | wert |  |
| `/sidebar` | Schaltet die Sidebar an oder aus. |  |  |
| `/duelnetwork <reload\|info\|backup\|debug>` | Verwaltung - reload, info, backup, debug. | dn | duelnetwork.admin |
| `/mute <Spieler> [Dauer, z. B. 2h] [Grund]` | Schaltet einen Spieler stumm (optional zeitlich begrenzt). |  | duelnetwork.mute |
| `/unmute <Spieler>` | Hebt eine Stummschaltung auf. |  | duelnetwork.mute |
| `/modlog <Spieler>` | Zeigt den Moderations-Verlauf eines Spielers (Bans, Kicks, Mutes). |  | duelnetwork.modlog |
| `/warp <Name>` | Teleportiert zu einem SMP-Warp. |  |  |
| `/warps` | Listet alle SMP-Warps. |  |  |
| `/setwarp <Name>` | Setzt einen Warp an deiner Position. |  | duelnetwork.warp |
| `/delwarp <Name>` | Loescht einen Warp. |  | duelnetwork.warp |
| `/back` | Zurueck zum letzten Ort oder Todesort (SMP). |  |  |
| `/claim <invite\|accept\|tp\|visitors\|create\|info\|list\|trust\|untrust\|delete>` | Erstellt und verwaltet geschützte Land-Claims. | claims, land | duelnetwork.claim.use |
| `/daily` | Taegliche Belohnung (Gems und Geld) mit Serien-Bonus. | tagesbelohnung |  |
| `/tpmenu` | Teleport-Menue (Homes, Warps, Spieler, Zurueck). | tpm |  |
| `/dnwartung [export\|backup\|backuptest\|config]` | Wartung - CSV-Export, Backup, Backup-Test, Konfig-Pruefung. | wartung | duelnetwork.admin |
| `/texturen` | Schaltet die Spezial-Texturen (LowBlock-Pack) an oder aus. | textures, texturepack |  |
| `/board <add\|remove\|list\|refresh\|types> ...` | Hologramm-Ranglisten aufstellen (Duell-Elo, Kills, Geld, Gems, Parkour-Rekorde ...). |  | duelnetwork.admin |
| `/friend [add\|accept\|deny\|remove\|tp\|tpaccept\|list\|notify] [Spieler]` | Freundesliste, Anfragen, Teleport zu Freunden. | f, freunde, friends |  |
| `/trade <Spieler> \| accept \| money <Betrag> \| cancel` | Sicherer Handel mit einem anderen Spieler. | handel |  |
| `/season [end]` | Duell-Season mit Restzeit, Top 10 und Ruhmeshalle. |  |  |
| `/note <Spieler> <Text>` | Team-Notiz zu einem Spieler anlegen. |  | duelnetwork.admin |
| `/notes <Spieler> [clear]` | Team-Notizen zu einem Spieler anzeigen. |  | duelnetwork.admin |
| `/tutorial [Seite]` | Kurze Einführung in alle Bereiche des Servers. | anleitung |  |
| `/matchstats` | Statistik deines letzten Duells nochmal anzeigen. | letztesduell, lastmatch |  |
| `/stats [Spieler]` | Profil mit Elo, Platz, Siegen, Gems und Geld. | profil |  |
| `/ranked` | Zwischen Ranked (Elo zählt) und Casual (Elo bleibt) umschalten. | casual |  |
| `/spectate [Spieler\|leave]` | Laufenden Duellen zuschauen. | spec, zuschauen |  |
| `/timeout <Spieler> [Dauer] [Grund]` | Chat-Timeout (Standard 10 Min). | | duelnetwork.mute |
| `/bounty [list\|set <Spieler> <Betrag>]` | Kopfgeld auf Spieler setzen und ansehen (SMP/Bau-SMP). | kopfgeld, bounties |  |
| `/gemboost [<2-10> [Minuten] \| off]` | Gem-Boost starten/beenden (Admin), ohne Argument Status. | | duelnetwork.admin |
| `/teamduel [leave]` | Team-Duelle (2v2–4v4) mit Party in der Warteschlange. | teamduell, teamduelle | |
| `/notify [claim\|mention\|bounty] [on\|off]` | Persönliche Benachrichtigungen ein-/ausschalten. | benachrichtigungen | |
| `/adminmenu` | Admin-Menü (Spieler, Gem-Boost, Events, Wartung). | amenu, adminmenue | duelnetwork.admin |
| `/mark [set <Name>\|del <Name>\|list\|<Name>]` | Persönliche Markierungen (SMP/Bau-SMP). | marks, markierung | |
| `/vanish` | Unsichtbar für normale Spieler. | | duelnetwork.admin |
| `/freeze <Spieler>` | Spieler festhalten/freigeben. | | duelnetwork.admin |
| `/invsee <Spieler>` | Inventar eines Online-Spielers ansehen. | | duelnetwork.admin |
| `/staffchat [Text]` | Team-Chat. | sc | duelnetwork.admin |

| `/settings` | Persönliche Einstellungen (Menü) |
| `/duelnetwork matches` | Admin: laufende Duelle, Warteschlangen, Event |
| `/duelnetwork maintenance [on\|off]` | Admin: Wartungsmodus |
| `/duelnetwork report` | Admin: Fehlerbericht als Datei |
| `/duelnetwork backup` / `restore list` | Admin: Backup erstellen oder auflisten |
| `/duelnetwork restore <Datei> confirm` | Admin: geprüften Restore beim nächsten Serverstart vormerken |
| `/duelladmin diagnose` | Admin: Setup, Config, Welten, Arenen und Kits prüfen |

| `/share [Text]` | Freunden deinen Ort zeigen (Klick-Teleport) |
| `/claim map` | Textkarte der Claims in deiner Umgebung |
| `/gems history` | Letzte Gem-Änderungen |
| `/duel last` | Zuletzt gespieltes Kit erneut |

## NPC-Skins importieren (Admin)

Für `/duelladmin npcskin <typ> import` die Datei `plugins/DuelNetwork/npc-skins/<typ>.yml` anlegen, zum Beispiel `duell.yml`, mit den Schlüsseln `texture-value: 'BASE64_TEXTURE_WERT'` und optional `texture-signature: 'BASE64_SIGNATUR'`. Der Wert ist die Mojang-Texture-Property (Base64-JSON), nicht die PNG-Datei. Mehrere Dateien gesammelt einspielen: `/duelladmin npcskin all import` importiert alle passenden, gültigen `<typ>.yml`-Dateien aus dem Ordner und aktualisiert vorhandene NPCs in kleinen Batches. Dateien vom PC bitte über das Server-Panel oder SFTP in den Plugin-Ordner hochladen; Minecraft selbst stellt einem Paper-Plugin keine lokale Datei-Drop-Funktion bereit. Für Rückkehr zum Spielernamen-Skin: `/duelladmin npcskin <typ> clear`; ein Spielername als drittes Argument setzt ebenfalls den Namens-Skin.
