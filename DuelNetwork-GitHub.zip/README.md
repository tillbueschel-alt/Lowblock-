# DuelNetwork 1.2.1

Ein-Welt-Netzwerk für Paper 1.21: **SMP**, **Duels**, **Bau-SMP**, **Events**, **Parkour**, Wirtschaft (Shop, Auktionshaus, Orders),
Anti-Cheat, Moderation. Items und Menüs nutzen normale Minecraft-Items; ein kleines Minimal-Pack liefert nur Logo und Rahmen für die Sidebar.

## Installation
1. Paper 1.21.x mit Java 21.
2. `DuelNetwork-1.2.1.jar` in den Ordner `plugins` legen, alte DuelNetwork-Jars und `plugins/.paper-remapped` löschen.
3. Server starten. Beim ersten Start entstehen `config.yml`, `messages.yml` und die Datendateien in `plugins/DuelNetwork`.
4. Ersten Owner festlegen: in der **Konsole** `op <Name>`, dann im Spiel `/rank <Name> Owner`. Danach kann der OP-Status wieder
   entfernt werden – Team-Rechte laufen über das Plugin (siehe Rechte).
5. Spawns, Arenen und Kits mit `/duelladmin` einrichten (Hinweise erscheinen beim Start für Admins).

Optional: **Vault** (Wirtschaft für andere Plugins) und **PlaceholderAPI** (Platzhalter). Beides wird nur genutzt, wenn installiert.

## Befehle
| Bereich | Befehle |
|---|---|
| Navigation | `/navigator`, `/lobby`, `/smp`, `/events`, `/parkour`, `/bausmp` |
| Duels | `/duel`, `/party`, `/duelstats`, `/rangliste` |
| SMP | `/home` `/sethome` `/delhome`, `/tpa`, `/rtp`, `/warp` `/warps`, `/back`, `/combat` |
| Wirtschaft | `/money`, `/pay`, `/baltop`, `/shop`, `/sell`, `/ah`, `/order`, `/market`, `/worth`, `/gems` |
| Claims | `/claim create`, `/claim info`, `/claim list`, `/claim trust`, `/claim untrust`, `/claim delete` |
| Chat | `/msg` `/r`, `/ignore`, `/report`, `/ping` |
| Team | `/ban`, `/unban`, `/kick`, `/mute`, `/unmute`, `/modlog`, `/rank`, `/reports`, `/anticheat`, `/setwarp`, `/delwarp`, `/duelladmin` |
| Verwaltung | `/duelnetwork reload\|info\|backup\|debug` |

`/ban <Spieler> [Dauer] <Grund>` und `/mute <Spieler> [Dauer] [Grund]` – Dauer z. B. `30m`, `12h`, `7d`, `2w`; ohne Angabe dauerhaft.

## Rechte
| Recht | Bedeutung | Standard |
|---|---|---|
| `duelnetwork.admin` | alle Team-Rechte (enthält die folgenden) | OP |
| `duelnetwork.ban` / `.unban` / `.kick` | Bann, Entbannen, Kick | über admin |
| `duelnetwork.mute` / `.modlog` | Stummschalten, Verlauf einsehen | über admin |
| `duelnetwork.rank` / `.reports` | Ränge vergeben, Meldungen lesen | über admin |
| `duelnetwork.warp` | Warps setzen und löschen | über admin |
| `duelnetwork.anticheat.bypass` | wird vom Anti-Cheat nicht geprüft | niemand |

Spieler mit dem Plugin-Rang *Admin* oder *Owner* bekommen `duelnetwork.admin` automatisch. Der Owner wird **nicht** mehr automatisch OP
(`ranks.owner-grants-op: false`); die häufigsten Vanilla-Befehle bekommt er über Permissions.

## Konfiguration (Auszug)
| Schlüssel | Bedeutung |
|---|---|
| `smp.*` | Grenzen, Teleport-Wartezeit, Combat-Zeiten |
| `economy.*`, `ah.*`, `orders.*` | Startgeld, Einkommen, Auktionshaus (Laufzeit, Angebote, `ah.tax-percent`), Audit-Schwelle |
| `duels.elo-k` | Elo-Faktor |
| `anticheat.*` | Grenzwerte, `punishment: kick\|ban\|none`, `ban-duration` |
| `backup.*` | Automatische Sicherung: an/aus, Intervall (Std.), Anzahl |
| `back.*` | `/back` an/aus, Todesort |
| `claims.*` | SQLite-Datei, Claim-Limit und -Größe, PvP-/Explosionsschutz |
| `debug` | ausführliche Fehlerausgabe |

Alle Texte der Moderations-, Mute-, Warp- und Admin-Funktionen stehen in `messages.yml` (Farben mit `&`, Platzhalter `{0}`, `{1}`).
Nach Änderungen: `/duelnetwork reload`.

## Daten und Sicherheit
- Alle Daten liegen als YAML in `plugins/DuelNetwork`. Geschrieben wird **asynchron und atomar** (`Store`), beim Herunterfahren wird alles zu Ende geschrieben.
- Claims liegen autoritativ in `plugins/DuelNetwork/claims.db` (SQLite, WAL, Foreign Keys und Schema-Version 1). Die lokalen Rollen sind `owner`, `member` (bauen und interagieren) und `trusted` (interagieren und Container öffnen).
- Claims sind rechteckige X/Z-Bereiche ausschließlich im Bau-SMP. `/claim create <Name> [Radius]` erstellt dort einen Bereich um den Spieler; Überschneidungen sowie Größen- und Spielerlimits werden abgelehnt. Im normalen PvP-SMP, in Lobby, Duellen und Parkour sind Claims deaktiviert.
- Geschützt werden Bauen, Abbauen, Flüssigkeiten, Türen/Redstone, Container, Item-Frames, Rüstungsständer, Explosionen, Pistons und mobbedingte Blockänderungen. `duelnetwork.claim.bypass` ist der explizite Admin-Bypass.
- **Backups:** Alle `*.yml` werden regelmäßig als ZIP nach `plugins/DuelNetwork/backups` gesichert (`backup.*`). Sofort: `/duelnetwork backup`.
- **Logs:** `moderation.log` (Bans, Kicks, Mutes), `audit.log` (Geld, Auktionshaus, Warps), `anticheat.log`.
- Nether und End bleiben bis zur Freischaltung über `/duelladmin unlock nether|end` auch für Portale in beide Richtungen und für `/rtp` gesperrt. `/rtp` ist innerhalb einer gesperrten Dimension ebenfalls blockiert.
- Die Gem-Werkzeuge verwenden Unbreaking X für die 3x3-/Baum-Aktionen und kosten 750/750/450 Gems. Der Bau-Shop enthält viele weitere Minecraft-Baublöcke und blätterbare Seiten; im normalen Nether-Shop ist auch Glowstone als Block verfügbar. Im Event-Menü steht ein Eisenschwert für 1v1/Turnier und ein Diamantschwert für FFA.
- Im Party-Menü ist die gleiche klare Zuordnung aktiv: Eisenschwert für Party-1v1 und Diamantschwert für Party-FFA. Die wiederkehrenden Sidebar-, Inventar- und Parkour-Prüfungen sind gedrosselt, um bei mehreren Spielern weniger Tick-Zeit zu verbrauchen.
- Die Bau-SMP-Shops werden automatisch aus den stapelbaren Minecraft-Blöcken aufgebaut und umfassen dadurch viele Seiten für Overworld, Nether und End. Im normalen SMP gibt es eine große, teure PvP-Ausrüstungskategorie mit Waffen, Äxten, Bögen, Schilden und Rüstungssets.
- Der Bau-SMP ist wieder normal abbaubar und baubar; nur fremde Claims bleiben geschützt. Der 3x3-Abbau und das Baumfällen berücksichtigen Unbreaking X auch bei den manuell abgebauten Zusatzblöcken. Die Gem-Schaufel nutzt ein korrektes Minecraft-Handheld-Modell.
- Die Config hat eine Versionsnummer (`config-version`) und wird bei Updates automatisch ergänzt; bestehende Werte bleiben erhalten.

## Anbindungen
- **Vault:** DuelNetwork registriert sich als Economy-Provider (Banken werden nicht unterstützt).
- **PlaceholderAPI:** `%duelnetwork_money%`, `_money_formatted`, `_money_rank`, `_gems`, `_wins`, `_losses`, `_elo`, `_streak`, `_rank`, `_muted`.

## Bauen
Java 21 und Gradle installieren, im Projektordner:

    gradle build

Die Jar liegt in `build/libs/DuelNetwork-1.2.1.jar`; `gradle test` führt die Tests aus. Der GitHub-Workflow `.github/workflows/build.yml`
baut und testet bei jedem Push.

Ab Version 1.1.7 ist `plugins/DuelNetwork/economy.db` die primäre Economy-Datenbank. Die alte `economy.yml` wird beim ersten Start automatisch migriert und als lesbares Backup behalten. Das SQLite-Ledger und das Recovery-Journal verhindern doppelte Geldbuchungen nach einem Serverabbruch. Ab 1.2.0 wird zusätzlich `claims.db` für Claims verwendet.

## Aufbau (src/main/java/de/server/network)
- `DuelNetworkPlugin` – Haupt-Plugin: Befehle, Kits, Parkour, Parteien, Minigames, Ränge.
- `Store` – asynchrones, atomares Speichern; `BackupManager` – Sicherungen; `Audit` – Handelsprotokoll; `Messages` – messages.yml.
- `Moderation`, `Mutes` – Bans, Kicks, Mutes, Verlauf; `Warps` – Warps und /back; `AdminCommand` – /duelnetwork.
- `Economy`, `Shop`, `AuctionHouse`, `Orders`, `Market`, `Gems`, `Values`, `ValueTags` – Wirtschaft.
- `AntiCheat`, `DuelFixes`, `DuelStats`, `RecordStore`, `KitLayouts`, `Events`, `EventGames`, `ParkourEnhancements`, `Rtp` u. a.
- `Claim`, `ClaimDatabase`, `ClaimManager`, `ClaimCommand`, `ClaimProtectionListener` – persistenter Land-Schutz mit lokalen Rollen.
- `VaultHook`, `PapiHook` – optionale Anbindungen. `Durations`, `Rules` – reine, testbare Logik.

## Hinweise vor dem Livebetrieb
- Das Plugin wurde ohne Zugriff auf die Paper-API entwickelt. Vor dem ersten Einsatz: bauen, auf einem Testserver die Abläufe in
  `TESTPLAN.md` durchgehen.
- **Lizenz:** noch festzulegen (Plugin und Texturpack). Ohne Lizenz gilt "alle Rechte vorbehalten".


## Neu in 1.6.0
Texte in `messages.yml`, Handels-Log, neue Kill-Effekte, Champion-Aura, `COMMANDS.md`.

## Neu in 1.5.0
`/stats`, `/ranked`, `/tutorial`, Aufräum-System (`cleanup.*`) und Task-Messung in `/dnwartung perf`.

## Neu in 1.4.0
Gem-Kosmetik (Armor-Trims im Duell, Kill-Effekte, Rohstoffe), Freundesliste (`/friend`), sicherer Handel (`/trade`), Duell-Seasons (`/season`), Parkour-Geister, Team-Notizen (`/note`, `/notes`) und Discord-Webhook. Details im CHANGELOG.
