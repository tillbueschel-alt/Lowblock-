# Einrichtung – alle Befehle in sinnvoller Reihenfolge

Alle `/duelladmin`-Befehle brauchen `duelnetwork.admin` (oder OP). Mit `/duelladmin help` siehst du die Liste im Spiel.
Alle Standorte werden dort gespeichert, wo du gerade stehst. Reihenfolge: einmal von oben nach unten durchgehen.

## 1. Vorbereitung
1. JAR in `plugins/`, Server starten, wieder stoppen. Es entstehen `config.yml` und `messages.yml`.
2. `config.yml` prüfen: `resourcepack.mode` (server/manual), `seasons`, `cleanup`, `webhook.url`.
3. Server starten. `/dnwartung config` prüft die Config auf Fehler.
4. Dir selbst Rechte geben: `/rank <Name> Owner` (oder OP / Permission `duelnetwork.admin`).

## 2. Spawns und Lobbys
| Befehl | Zweck |
|---|---|
| `/duelladmin setlobby haupt` | Haupt-Lobby |
| `/duelladmin setlobby duell` | Duell-Lobby |
| `/duelladmin setlobby events` | Event-Lobby |
| `/duelladmin setlobby parkour` | Parkour-Lobby |
| `/duelladmin setlobby creative` | Bau-SMP-Lobby |
| `/duelladmin setspawn smp` | SMP-Spawn (setzt auch die SMP-Weltgrenze) |
| `/duelladmin setspawn creative` | Bau-SMP-Spawn |
| `/duelladmin setspawn duell` / `events` / `parkour` | weitere Spielmodus-Spawns (optional mit Namen: `setspawn smp <name>`) |

## Homes in SMP und Bau-SMP
`/sethome <Name>`, `/home <Name>` und `/delhome <Name>` verwenden getrennte Speicherlisten: Homes im normalen SMP erscheinen nicht im Bau-SMP und umgekehrt. Spieler ohne Rang haben bis zu 3 Homes **pro Modus**; berechtigte Ränge haben bis zu 5 pro Modus. Bereits vorhandene Homes werden beim ersten Zugriff automatisch dem normalen SMP zugeordnet.

## 3. NPCs (Menü-Figuren)
| Befehl | Zweck |
|---|---|
| `/duelladmin npc navigator` | Navigator-NPC an deiner Position |
| `/duelladmin npc smp` / `duell` / `events` / `parkour` / `creative` | NPC je Bereich |
| `/duelladmin npcskin <Typ> <MinecraftName>` | Skin des NPCs ändern |
| `/duelladmin npclock <Typ> <on|off>` | NPC sperren oder freigeben |
| `/duelladmin npcfix` | NPCs neu stylen, alte Villager umwandeln |

## 4. Duell-Arenen und Kits
| Befehl | Zweck |
|---|---|
| `/duelladmin arena create <Name>` | Arena anlegen |
| `/duelladmin arena pos1 <Name>` und `pos2 <Name>` | zwei Ecken der Arena setzen |
| `/duelladmin setduelspawn <Arena> 1` und `2` | Spawnpunkte der beiden Spieler |
| `/duelladmin arena check <Name>` / `list` / `delete <Name>` | prüfen, auflisten, löschen |
| `/duelladmin kit create <Name>` | Kit aus deinem Inventar anlegen |
| `/duelladmin kit save <Name>` | Kit überschreiben |
| `/duelladmin kitedit <Name>` | Inventar des Kits sortieren |
| `/duelladmin kit list` / `delete <Name>` | auflisten, löschen |

## 5. Parkour
| Befehl | Zweck |
|---|---|
| `/duelladmin parkour create <Map>` | Map anlegen |
| `/duelladmin parkour start <Map>` | Startpunkt |
| `/duelladmin parkour end <Map>` | Ziel |
| `/duelladmin parkour checkpoint <Map> <Nummer>` | Checkpoints (1, 2, 3 …) |
| `/duelladmin parkour fall1 <Map>` und `fall2 <Map>` | Sturzzone (zwei Ecken), Spieler kommen zum Checkpoint zurück |
| `/duelladmin parkour check <Map>` / `list` / `delete <Map>` | prüfen, auflisten, löschen |
| `/duelladmin records <Spieler>` | Rekorde ansehen/löschen; `records list|reset|map …` |

## 6. Events, Spiele, Spezielles
| Befehl | Zweck |
|---|---|
| `/duelladmin event add|remove|list …` | Events verwalten |
| `/duelladmin seteventspawn <Event>` | Spawn eines Events |
| `/duelladmin game …` | Event-Spiele (siehe `/duelladmin game` im Spiel) |
| `/duelladmin egg …` | Drachenei (siehe `/duelladmin egg` im Spiel) |
| `/duelladmin unlock nether` / `end` und `/duelladmin lock …` | Nether/End sofort öffnen oder sperren |
| `/duelladmin unlock start <nether|end> [24h]` | Freischaltung mit Countdown planen (Standard 24 h; auch `1d`, `12h`, `30m`); Restzeitmeldungen gehen nur an Spieler im normalen SMP |
| `/duelladmin unlock status` | Freischaltstatus und verbleibende Countdown-Zeit anzeigen |
| `/duelladmin eco …` | Wirtschaft verwalten (siehe `/duelladmin eco` im Spiel) |
| `/duelladmin icon <Eintrag> <MATERIAL|hand|reset>` | Icons der Menüs ändern |

## 7. Anzeige und Warps
| Befehl | Zweck |
|---|---|
| `/board add <Typ> [Map]` | Hologramm-Bestenliste an deiner Position. Typen: `elo, wins, streak, kills, playtime, money, bau-money, gems, parkour` (parkour braucht `[Map]`) |
| `/board list` / `remove` / `refresh` / `types` | verwalten |
| `/setwarp <Name>` / `/delwarp <Name>` | Warps (Recht `duelnetwork.warp`) |

## 8. Team und Moderation
| Befehl | Zweck |
|---|---|
| `/rank <Spieler> <Media|Owner|Admin|Premium|Tester|reset>` | Ränge vergeben |
| `/ban`, `/unban`, `/kick`, `/mute`, `/unmute`, `/modlog` | Moderation |
| `/reports [clear]`, `/note`, `/notes` | Meldungen und Notizen |
| `/anticheat [on|off|alerts|info|alts|top|log|reset|xray]` | Anti-Cheat |

## 9. Wartung und Test
| Befehl | Zweck |
|---|---|
| `/duelnetwork reload` | Config und `messages.yml` neu laden (Port und Pack-Modus brauchen Neustart) |
| `/duelnetwork backup` / `restore list` | Backup erstellen oder vorhandene Archive auflisten |
| `/duelnetwork restore <Dateiname> confirm` | Archiv prüfen und beim nächsten Serverstart sicher wiederherstellen |
| `/duelladmin diagnose` | Spawns, Lobby, Arenen, Kits und Config ohne Chunk-Scan pruefen |
| `/dnwartung export|backup|backuptest|config|perf` | Wartung, Backup prüfen, Leistung messen |
| `/season end` | Season sofort beenden (Test!) |
| `/texturen` | Pack-Status/Download für Spieler |
| `/gems give <Spieler> <Menge>` | Gems vergeben (Test) |

## Empfohlene Test-Reihenfolge
1. Spawns und Lobby setzen, `/lobby` testen.
2. Arena + Kit anlegen, mit einem zweiten Account `/duel` spielen.
3. Parkour-Map mit Start/Ende/Checkpoint/Fall, zweimal durchlaufen (Geist prüfen).
4. NPCs setzen, Menüs durchklicken.
5. `/dnwartung perf` nach ein paar Minuten ansehen.

Die vollständige Befehlsliste für Spieler und Admins steht in `COMMANDS.md`.

## Duell-Lobby mit NPCs (ab 1.8.0)
In der Duell-Lobby (`/duelladmin setspawn duell`) nebeneinander stellen, jeweils an der Stelle stehen und eingeben:
- `/duelladmin npc duell` – Einzelkampf (Kit-Menue, Warteschlange)
- `/duelladmin npc ranked` – schaltet auf **Mit Elo** und oeffnet das Kit-Menue
- `/duelladmin npc unranked` – schaltet auf **Ohne Elo** und oeffnet das Kit-Menue
- `/duelladmin npc team` – Team-Duelle: Party mit genau 2, 3 oder 4 Spielern gegen eine andere Party gleicher Groesse (Kit waehlen, Warteschlange). Ohne NPC geht es auch mit `/teamduel`.
Skins sind mit `/duelladmin npcskin <typ> <Spielername>` oder in `npc-skins.<typ>.name` anpassbar (Standard: MHF_Blaze, MHF_Chicken, MHF_Zombie).

### Importierte NPC-Skins (ab 1.8.1)
1. Von einem Skin-Dienst eine Mojang-Texture-Property beziehen: den Base64-`value` und nach Möglichkeit die passende `signature`. Eine rohe PNG-Datei kann Minecraft nicht direkt als NPC-Profiltextur verwenden.
2. Auf dem Server die Datei `plugins/DuelNetwork/npc-skins/<typ>.yml` anlegen, zum Beispiel `duell.yml`:
   ```yaml
   texture-value: 'BASE64_TEXTURE_WERT'
   texture-signature: 'BASE64_SIGNATUR'
   ```
3. `/duelladmin npcskin <typ> import` ausführen. Der Import wird in `config.yml` gespeichert und vorhandene NPCs dieses Typs werden aktualisiert.
4. Mit `/duelladmin npcskin <typ> clear` den Import entfernen und wieder den Spielernamen-Skin verwenden.

Für mehrere Skins auf einmal die Dateien für die gewünschten Typen gesammelt in denselben Ordner legen und `/duelladmin npcskin all import` ausführen. Unterstützte Dateinamen entsprechen den NPC-Typen, etwa `duell.yml`, `smp.yml`, `ranked.yml` oder `navigator.yml`; ungültige Dateien werden übersprungen und gemeldet. Dateien vom eigenen Rechner lassen sich nicht per Drag-and-drop in das Minecraft-Spiel importieren. Lade sie über den Dateimanager im Server-Panel oder per SFTP in den Ordner `plugins/DuelNetwork/npc-skins/` hoch.

## Team-Spawns in der Arena (ab 1.8.0)
Fuer Team-Duelle (2v2–4v4) kannst du pro Team mehrere Startpunkte setzen. Stelle dich an die Stelle und gib ein:
- `/duelladmin setduelspawn <Arena> 1` – Hauptspawn Team 1 (wie bisher)
- `/duelladmin setduelspawn <Arena> 1 2` – zweiter Platz Team 1 (weiter mit `1 3`, `1 4`)
- `/duelladmin setduelspawn <Arena> 2` / `2 2` / `2 3` / `2 4` – dasselbe fuer Team 2
Der erste Spieler eines Teams steht am Hauptspawn, der zweite auf Platz 2 usw. Fehlt ein Platz, steht der Spieler am Hauptspawn.

## Arena-Groesse und Pflichtpositionen
Es gibt keine Mindestgroesse und keine feste Block-Obergrenze fuer Duell-Arenen. Erforderlich sind `pos1`, `pos2`, `spawn1` und `spawn2`; alle vier Positionen muessen Koordinaten in derselben geladenen Welt haben. `pos1`/`pos2` legen den Resetbereich fest, die Spawns die Startpunkte. Pruefen mit `/duelladmin arena check <Name>` oder `/duelladmin arena list`. Snapshots und Resets werden in konfigurierbaren Batches pro Tick aufgenommen/zurueckgesetzt, damit grosse Arenen keine einzelne lange Tick-Spitze erzeugen; sie benoetigen trotzdem entsprechend Arbeitsspeicher und Gesamtzeit.

## Trainings-Dummy (ab 1.8.0)
In der Duell-Lobby `/duelladmin npc dummy` – der NPC zeigt beim Schlagen Schaden, Treffer und DPS in der Actionbar.

## Duell-Lobby einrichten
1. In der Duell-Lobby stehen: `/duelladmin setlobby duell`
2. NPCs dort setzen: `/duelladmin npc ranked`, `/duelladmin npc unranked`, `/duelladmin npc team`
3. In der Haupt-Lobby: `/duelladmin npc duell` (Name: Duelle). Der Navigator (Kompass) bringt ebenfalls dorthin.
4. Alte NPCs bekommen die neuen Namen nach einem Neustart oder über den Namen-Refresh.

In der Duell-Lobby erscheinen Navigator, Party und Duell-Kit-Auswahl automatisch auf der Hotbar. In Dummy-Nähe kommen ein unzerstörbares Diamantschwert und eine Diamantaxt dazu; sie werden beim Verlassen des Bereichs entfernt und nicht als normales Spielerinventar gespeichert. Für die Event-Lobby `/duelladmin setlobby events` setzen; Event-NPC und Navigator führen dorthin, wenn ein Ziel gesetzt ist. Dort gibt es Event-Menü, Navigator und Party-Hotbar.

Nether-/End-Portale und `/rtp` sind nur im normalen SMP nutzbar. Gesperrte Welten lassen sich nicht betreten, die Rückreise in die Overworld bleibt möglich. Das End öffnet sich erst, wenn der Countdown (oder ein sofortiges Admin-Unlock) abgeschlossen **und** der Enderdrache besiegt ist. Das Öffnen per Countdown wird über Neustarts hinweg gespeichert.

## Diagnose und Datensicherung

Backups werden standardmaessig alle 6 Stunden im Hintergrund erstellt und enthalten YAML-Dateien sowie konsistente SQLite-Snapshots von Economy und Claims. `/dnwartung backuptest` prueft die YAML-Syntax und SQLite-Integritaet. Archive liegen unter `plugins/DuelNetwork/backups`; da sie auf demselben Datentraeger wie die Quelldaten liegen, sollte zusaetzlich eine Kopie auf einen getrennten, geschuetzten Speicher uebertragen werden.

Fuer einen Restore zuerst mit `/duelnetwork restore list` ein Archiv auswaehlen, dann `/duelnetwork restore <Dateiname> confirm` ausfuehren. Das Plugin prueft das Archiv, erstellt eine Rueckfallkopie und wendet den Restore erst beim naechsten vollstaendigen Serverstart an. Der Restore ersetzt die im gewaehlten Archiv enthaltenen Dateien.
