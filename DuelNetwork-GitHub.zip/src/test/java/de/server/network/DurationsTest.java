package de.server.network;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class DurationsTest {
    @Test
    void parsesAllUnits() {
        assertEquals(45_000L, Durations.parse("45s"));
        assertEquals(30L * 60_000L, Durations.parse("30m"));
        assertEquals(12L * 3_600_000L, Durations.parse("12h"));
        assertEquals(7L * 86_400_000L, Durations.parse("7d"));
        assertEquals(14L * 86_400_000L, Durations.parse("2w"));
    }

    @Test
    void isCaseInsensitiveAndTrims() {
        assertEquals(86_400_000L, Durations.parse(" 1D "));
    }

    @Test
    void rejectsNonDurations() {
        assertEquals(-1L, Durations.parse("spam"));
        assertEquals(-1L, Durations.parse("7"));
        assertEquals(-1L, Durations.parse("d7"));
        assertEquals(-1L, Durations.parse(""));
        assertEquals(-1L, Durations.parse(null));
        assertEquals(-1L, Durations.parse("-5m"));
    }

    @Test
    void describesReadably() {
        assertEquals("dauerhaft", Durations.describe(0L));
        assertEquals("dauerhaft", Durations.describe(-1L));
        assertEquals("1 Min.", Durations.describe(10_000L));
        assertEquals("90 Min.", Durations.describe(90L * 60_000L));
        assertEquals("12 Std.", Durations.describe(12L * 3_600_000L));
        assertEquals("7 Tage", Durations.describe(7L * 86_400_000L));
    }
}
