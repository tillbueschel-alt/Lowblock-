package de.server.network;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class RulesTest {
    @Test
    void noTaxMeansFullPrice() {
        assertEquals(1000L, Rules.proceeds(1000L, 0L));
    }

    @Test
    void taxIsDeducted() {
        assertEquals(900L, Rules.proceeds(1000L, 10L));
        assertEquals(950L, Rules.proceeds(1000L, 5L));
    }

    @Test
    void taxIsCappedAtFiftyPercentAndNeverNegative() {
        assertEquals(500L, Rules.proceeds(1000L, 99L));
        assertEquals(1000L, Rules.proceeds(1000L, -20L));
    }

    @Test
    void invalidPriceGivesNothing() {
        assertEquals(0L, Rules.proceeds(0L, 10L));
        assertEquals(0L, Rules.proceeds(-5L, 10L));
    }

    @Test
    void listLimitIsClampedToAvailableRows() {
        assertEquals(0, Rules.boundedLimit(-3, 10));
        assertEquals(0, Rules.boundedLimit(10, 0));
        assertEquals(4, Rules.boundedLimit(4, 10));
        assertEquals(10, Rules.boundedLimit(99, 10));
    }

    @Test
    void equalPlayersSwapHalfTheFactor() {
        int[] r = Rules.elo(1000, 1000, 32);
        assertArrayEquals(new int[]{1016, 984, 16, 16}, r);
    }

    @Test
    void upsetGivesMorePointsThanExpectedWin() {
        int upset = Rules.elo(900, 1200, 32)[2];
        int expected = Rules.elo(1200, 900, 32)[2];
        assertTrue(upset > expected);
    }

    @Test
    void loserNeverFallsBelowHundred() {
        int[] near = Rules.elo(1500, 105, 32);
        assertEquals(104, near[1]);
        int[] floor = Rules.elo(1500, 100, 32);
        assertEquals(100, floor[1]);
        assertEquals(0, floor[3]);
        assertTrue(floor[0] > 1500);
    }
}
