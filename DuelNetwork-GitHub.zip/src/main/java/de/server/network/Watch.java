package de.server.network;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;

/**
 * Zuschauen bei laufenden Duellen: /spectate oeffnet eine Liste der Kaempfer, /spectate &lt;Spieler&gt; geht direkt hin,
 * /spectate leave bringt zurueck. Wenn das Duell endet (oder der Zuschauer die Lobby verlaesst), wird automatisch zurueckgeholt.
 */
final class Watch implements CommandExecutor, TabCompleter, Listener {
    static Watch instance;

    private static final String TAG = "Zuschauen";

    private final DuelNetworkPlugin plugin;
    private final Map<UUID, Location> origins = new HashMap<UUID, Location>();
    private final Map<UUID, GameMode> modes = new HashMap<UUID, GameMode>();
    private final Map<UUID, UUID> targets = new HashMap<UUID, UUID>();

    Watch(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
        instance = this;
        // alle 2 Sekunden pruefen, ob das beobachtete Duell noch laeuft
        plugin.getServer().getScheduler().runTaskTimer((Plugin)plugin, this::check, 40L, 40L);
        // Actionbar mit Namen und Leben der Kaempfer (1x pro Sekunde, nur fuer Zuschauer)
        plugin.getServer().getScheduler().runTaskTimer((Plugin)plugin, Perf.wrap("Spectate", this::actionbar), 20L, 20L);
    }

    void shutdown() {
        for (UUID id : new ArrayList<UUID>(this.origins.keySet())) {
            Player player = this.plugin.getServer().getPlayer(id);
            if (player != null) {
                this.stop(player, false);
            }
        }
    }

    private void check() {
        for (UUID id : new ArrayList<UUID>(this.targets.keySet())) {
            Player spectator = this.plugin.getServer().getPlayer(id);
            Player target = this.plugin.getServer().getPlayer(this.targets.get(id));
            if (spectator == null) {
                this.forget(id);
            } else if (target == null || !this.plugin.inActiveMatch(target.getUniqueId())) {
                this.stop(spectator, true);
                spectator.sendMessage("§7Das Duell ist beendet.");
            }
        }
    }

    private static String hearts(Player player) {
        return String.format(Locale.ROOT, "%.1f", Math.max(0.0, player.getHealth() / 2.0));
    }

    private void actionbar() {
        for (Map.Entry<UUID, UUID> e : this.targets.entrySet()) {
            Player spectator = this.plugin.getServer().getPlayer(e.getKey());
            Player target = this.plugin.getServer().getPlayer(e.getValue());
            if (spectator == null || target == null) {
                continue;
            }
            Player other = this.plugin.getServer().getPlayer(this.plugin.duelPartners.getOrDefault(target.getUniqueId(), target.getUniqueId()));
            String text = "§f" + target.getName() + " §c❤ " + hearts(target);
            if (other != null && !other.equals(target)) {
                text += " §8⚔ §f" + other.getName() + " §c❤ " + hearts(other);
            }
            spectator.sendActionBar(net.kyori.adventure.text.Component.text(text));
        }
    }

    /** Zuschauer duerfen nicht durch Bloecke fliegen und sich nicht weit vom Kaempfer entfernen (watch.max-distance, Standard 40). */
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player spectator = event.getPlayer();
        UUID targetId = this.targets.get(spectator.getUniqueId());
        if (targetId == null || event.getTo() == null) {
            return;
        }
        Location to = event.getTo();
        if (event.getFrom().getBlockX() == to.getBlockX() && event.getFrom().getBlockY() == to.getBlockY() && event.getFrom().getBlockZ() == to.getBlockZ()) {
            return;
        }
        Player target = this.plugin.getServer().getPlayer(targetId);
        double max = Math.max(10.0, this.plugin.getConfig().getDouble("watch.max-distance", 40.0));
        if (target != null && target.getWorld().equals(to.getWorld()) && target.getLocation().distanceSquared(to) > max * max) {
            event.setTo(target.getLocation());
            spectator.sendMessage("§7Du kannst dich nicht weiter vom Kampf entfernen.");
            return;
        }
        if (to.getBlock().getType().isSolid() || to.clone().add(0.0, 1.0, 0.0).getBlock().getType().isSolid()) {
            event.setCancelled(true);
        }
    }

    private void forget(UUID id) {
        this.origins.remove(id);
        this.modes.remove(id);
        this.targets.remove(id);
    }

    private void start(Player spectator, Player target) {
        UUID id = spectator.getUniqueId();
        if (!this.targets.containsKey(id)) {
            if (!this.plugin.isIdleInLobby(spectator)) {
                spectator.sendMessage("§cZuschauen geht nur aus der Lobby, wenn du nicht in einem Duel bist.");
                return;
            }
            this.origins.put(id, spectator.getLocation().clone());
            this.modes.put(id, spectator.getGameMode());
        }
        if (!this.plugin.inActiveMatch(target.getUniqueId()) || target.equals(spectator)) {
            spectator.sendMessage("§c" + target.getName() + " ist in keinem laufenden Duel.");
            return;
        }
        this.targets.put(id, target.getUniqueId());
        spectator.setGameMode(GameMode.SPECTATOR);
        spectator.teleport(target.getLocation());
        spectator.sendMessage("§d⚔ §7Du siehst §f" + target.getName() + " §7zu. Zurück mit §d/spectate leave§7.");
    }

    private void stop(Player spectator, boolean teleport) {
        UUID id = spectator.getUniqueId();
        Location origin = this.origins.get(id);
        GameMode mode = this.modes.getOrDefault(id, GameMode.SURVIVAL);
        this.forget(id);
        spectator.setGameMode(mode == GameMode.SPECTATOR ? GameMode.SURVIVAL : mode);
        if (teleport && origin != null && origin.getWorld() != null) {
            spectator.teleport(origin);
        }
    }

    private void openList(Player player) {
        Inventory inv = Gui.frame(this.plugin, TAG, "Laufende Duelle", 54);
        int slot = 10;
        List<UUID> shown = new ArrayList<UUID>();
        for (UUID id : this.plugin.activeDuelFighters()) {
            Player fighter = this.plugin.getServer().getPlayer(id);
            if (fighter == null || shown.contains(id) || slot > 43) {
                continue;
            }
            if (slot % 9 == 8) {
                slot += 2;
            }
            ItemStack head = Gui.item(Material.PLAYER_HEAD, "§f" + fighter.getName(), "§7Duel: §f" + this.plugin.duelKitLabel(id), "§e▶ Klicken zum Zuschauen");
            if (head.getItemMeta() instanceof SkullMeta meta) {
                meta.setOwningPlayer(fighter);
                head.setItemMeta(meta);
            }
            inv.setItem(slot++, head);
            shown.add(id);
        }
        if (shown.isEmpty()) {
            inv.setItem(22, Gui.item(Material.BARRIER, "§7Gerade läuft kein Duel", "§8Schau später nochmal vorbei."));
        }
        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!Gui.isTitle(event.getView().getTitle(), TAG)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        ItemStack stack = event.getCurrentItem();
        if (stack == null || stack.getType() != Material.PLAYER_HEAD || !stack.hasItemMeta()) {
            return;
        }
        String name = org.bukkit.ChatColor.stripColor(stack.getItemMeta().getDisplayName());
        Player target = this.plugin.getServer().getPlayerExact(name);
        player.closeInventory();
        if (target != null) {
            this.start(player, target);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (Gui.isTitle(event.getView().getTitle(), TAG)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (this.targets.containsKey(player.getUniqueId())) {
            this.stop(player, true);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Dieser Befehl ist nur fuer Spieler.");
            return true;
        }
        if (args.length >= 1 && (args[0].equalsIgnoreCase("leave") || args[0].equalsIgnoreCase("stop"))) {
            if (this.targets.containsKey(player.getUniqueId())) {
                this.stop(player, true);
                player.sendMessage("§7Du schaust nicht mehr zu.");
            } else {
                player.sendMessage("§7Du schaust gerade niemandem zu.");
            }
            return true;
        }
        if (args.length == 0) {
            this.openList(player);
            return true;
        }
        Player target = this.plugin.getServer().getPlayerExact(args[0]);
        if (target == null) {
            player.sendMessage("§cDieser Spieler ist nicht online.");
            return true;
        }
        this.start(player, target);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<String>();
        if (args.length == 1) {
            if ("leave".startsWith(args[0].toLowerCase(Locale.ROOT))) {
                out.add("leave");
            }
            for (UUID id : this.plugin.activeDuelFighters()) {
                Player fighter = this.plugin.getServer().getPlayer(id);
                if (fighter != null && fighter.getName().toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(fighter.getName());
                }
            }
        }
        return out;
    }
}
