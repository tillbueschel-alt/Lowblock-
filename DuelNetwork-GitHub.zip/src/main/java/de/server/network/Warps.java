package de.server.network;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/**
 * SMP-Warps (/warp, /warps, /setwarp, /delwarp) und /back (zurueck zum letzten Ort oder Todesort).
 * Teleports nutzen dieselbe Wartezeit, denselben Combat-Schutz und dieselbe SMP-Grenze wie /home.
 */
final class Warps implements Listener, CommandExecutor, TabCompleter {
    private static final Pattern NAME = Pattern.compile("^[a-z0-9_-]{1,24}$");
    private static final int MAX_WARPS = 50;

    private final DuelNetworkPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Map<UUID, Location> back = new ConcurrentHashMap<UUID, Location>();

    Warps(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "warps.yml");
        this.data = YamlConfiguration.loadConfiguration(this.file);
    }

    private void save() {
        try {
            Store.save(this.data, this.file);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("warps.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private List<String> names() {
        ConfigurationSection section = this.data.getConfigurationSection("warps");
        List<String> out = new ArrayList<String>();
        if (section != null) {
            out.addAll(section.getKeys(false));
        }
        Collections.sort(out);
        return out;
    }

    private Location read(String name) {
        String base = "warps." + name;
        if (!this.data.contains(base + ".world")) {
            return null;
        }
        World world = this.plugin.getServer().getWorld(this.data.getString(base + ".world", ""));
        if (world == null) {
            return null;
        }
        return new Location(world, this.data.getDouble(base + ".x"), this.data.getDouble(base + ".y"), this.data.getDouble(base + ".z"),
                (float)this.data.getDouble(base + ".yaw"), (float)this.data.getDouble(base + ".pitch"));
    }

    private boolean inSmp(Player player) {
        return "smp".equals(this.plugin.profiles.getOrDefault(player.getUniqueId(), "lobby"));
    }

    /* ---------- /back: Orte merken ---------- */

    private void remember(Player player, Location location) {
        if (location == null || location.getWorld() == null || !this.inSmp(player)) {
            return;
        }
        if (!this.plugin.isInsideSmpBorder(location) || this.plugin.isInLobby(location)) {
            return;
        }
        this.back.put(player.getUniqueId(), location.clone());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.COMMAND || cause == PlayerTeleportEvent.TeleportCause.PLUGIN) {
            this.remember(event.getPlayer(), event.getFrom());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        if (this.plugin.getConfig().getBoolean("back.death", true)) {
            this.remember(event.getEntity(), event.getEntity().getLocation());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.back.remove(event.getPlayer().getUniqueId());
    }

    /* ---------- Befehle ---------- */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Dieser Befehl ist nur fuer Spieler.");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "warp" -> this.warp(player, args);
            case "warps" -> this.list(player);
            case "setwarp" -> this.setWarp(player, args);
            case "delwarp" -> this.delWarp(player, args);
            case "back" -> this.back(player);
            default -> {
            }
        }
        return true;
    }

    private void list(Player player) {
        List<String> names = this.names();
        player.sendMessage(names.isEmpty() ? Messages.get("warp.list-empty") : Messages.get("warp.list", String.join("§7, §f", names)));
    }

    private void warp(Player player, String[] args) {
        if (args.length < 1) {
            this.list(player);
            player.sendMessage(Messages.get("warp.usage"));
            return;
        }
        if (!this.inSmp(player)) {
            player.sendMessage(Messages.get("common.only-smp"));
            return;
        }
        if (this.plugin.isInSmpCombat(player)) {
            player.sendMessage(Messages.get("common.in-combat"));
            return;
        }
        String name = args[0].toLowerCase(Locale.ROOT);
        Location target = this.read(name);
        if (target == null) {
            player.sendMessage(Messages.get("warp.unknown", args[0]));
            return;
        }
        this.plugin.scheduleDelayedTeleport(player, target, "Warp " + name);
    }

    private void setWarp(Player player, String[] args) {
        if (args.length != 1) {
            player.sendMessage(Messages.get("warp.setwarp-usage"));
            return;
        }
        String name = args[0].toLowerCase(Locale.ROOT);
        if (!NAME.matcher(name).matches()) {
            player.sendMessage(Messages.get("warp.bad-name"));
            return;
        }
        if (!this.data.contains("warps." + name) && this.names().size() >= MAX_WARPS) {
            player.sendMessage(Messages.get("warp.limit"));
            return;
        }
        Location at = player.getLocation();
        String base = "warps." + name;
        this.data.set(base + ".world", at.getWorld().getName());
        this.data.set(base + ".x", at.getX());
        this.data.set(base + ".y", at.getY());
        this.data.set(base + ".z", at.getZ());
        this.data.set(base + ".yaw", (double)at.getYaw());
        this.data.set(base + ".pitch", (double)at.getPitch());
        this.save();
        Audit.log("WARP", player.getName() + " hat Warp " + name + " gesetzt (" + at.getBlockX() + ", " + at.getBlockY() + ", " + at.getBlockZ() + ")");
        player.sendMessage(Messages.get("warp.set", name));
    }

    private void delWarp(Player player, String[] args) {
        if (args.length != 1) {
            player.sendMessage(Messages.get("warp.delwarp-usage"));
            return;
        }
        String name = args[0].toLowerCase(Locale.ROOT);
        if (!this.data.contains("warps." + name)) {
            player.sendMessage(Messages.get("warp.unknown", args[0]));
            return;
        }
        this.data.set("warps." + name, null);
        this.save();
        Audit.log("WARP", player.getName() + " hat Warp " + name + " geloescht");
        player.sendMessage(Messages.get("warp.deleted", name));
    }

    private void back(Player player) {
        if (!this.plugin.getConfig().getBoolean("back.enabled", true)) {
            player.sendMessage(Messages.get("back.disabled"));
            return;
        }
        if (!this.inSmp(player)) {
            player.sendMessage(Messages.get("common.only-smp"));
            return;
        }
        if (this.plugin.isInSmpCombat(player)) {
            player.sendMessage(Messages.get("common.in-combat"));
            return;
        }
        Location target = this.back.get(player.getUniqueId());
        if (target == null || target.getWorld() == null) {
            player.sendMessage(Messages.get("back.none"));
            return;
        }
        this.plugin.scheduleDelayedTeleport(player, target, "deinem letzten Ort");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<String>();
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (args.length == 1 && (name.equals("warp") || name.equals("delwarp"))) {
            out.addAll(this.names());
        }
        String typed = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(entry -> !entry.startsWith(typed));
        return out;
    }
}
