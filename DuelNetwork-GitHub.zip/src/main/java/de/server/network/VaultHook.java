package de.server.network;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

/**
 * Stellt die DuelNetwork-Wirtschaft ueber Vault bereit, damit andere Plugins (Chat, Shops, Scoreboards ...)
 * dieselben Kontostaende nutzen. Wird nur geladen, wenn Vault installiert ist.
 * Hinweis: Der Klassenname Economy ist im Paket schon vergeben, deshalb steht das Vault-Interface voll qualifiziert da.
 */
final class VaultHook implements net.milkbowl.vault.economy.Economy {
    private final DuelNetworkPlugin plugin;

    private VaultHook(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
    }

    static void register(DuelNetworkPlugin plugin) {
        plugin.getServer().getServicesManager().register(net.milkbowl.vault.economy.Economy.class, new VaultHook(plugin), plugin, ServicePriority.Highest);
    }

    private UUID idOf(String name) {
        OfflinePlayer player = this.plugin.moderation.cached(name);
        return player == null ? null : player.getUniqueId();
    }

    private static long cents(double amount) {
        return Math.round(amount);
    }

    private EconomyResponse fail(String message) {
        return new EconomyResponse(0.0, 0.0, ResponseType.FAILURE, message);
    }

    private EconomyResponse noBank() {
        return new EconomyResponse(0.0, 0.0, ResponseType.NOT_IMPLEMENTED, "DuelNetwork unterstützt keine Banken.");
    }

    /* ---------- Allgemeines ---------- */

    public boolean isEnabled() {
        return true;
    }

    public String getName() {
        return "DuelNetwork";
    }

    public boolean hasBankSupport() {
        return false;
    }

    public int fractionalDigits() {
        return 0;
    }

    public String format(double amount) {
        return Gui.money(cents(amount));
    }

    public String currencyNamePlural() {
        return "Dollar";
    }

    public String currencyNameSingular() {
        return "Dollar";
    }

    /* ---------- Konten ---------- */

    public boolean hasAccount(OfflinePlayer player) {
        return Economy.hasAccount(player.getUniqueId());
    }

    public boolean hasAccount(String name) {
        UUID id = this.idOf(name);
        return id != null && Economy.hasAccount(id);
    }

    public boolean hasAccount(OfflinePlayer player, String world) {
        return this.hasAccount(player);
    }

    public boolean hasAccount(String name, String world) {
        return this.hasAccount(name);
    }

    public boolean createPlayerAccount(OfflinePlayer player) {
        Economy.ensureAccount(player.getUniqueId(), player.getName());
        return true;
    }

    public boolean createPlayerAccount(String name) {
        UUID id = this.idOf(name);
        if (id == null) {
            return false;
        }
        Economy.ensureAccount(id, name);
        return true;
    }

    public boolean createPlayerAccount(OfflinePlayer player, String world) {
        return this.createPlayerAccount(player);
    }

    public boolean createPlayerAccount(String name, String world) {
        return this.createPlayerAccount(name);
    }

    /* ---------- Kontostand ---------- */

    public double getBalance(OfflinePlayer player) {
        return Economy.balance(player.getUniqueId());
    }

    public double getBalance(String name) {
        UUID id = this.idOf(name);
        return id == null ? 0.0 : Economy.balance(id);
    }

    public double getBalance(OfflinePlayer player, String world) {
        return this.getBalance(player);
    }

    public double getBalance(String name, String world) {
        return this.getBalance(name);
    }

    public boolean has(OfflinePlayer player, double amount) {
        return Economy.has(player.getUniqueId(), cents(amount));
    }

    public boolean has(String name, double amount) {
        UUID id = this.idOf(name);
        return id != null && Economy.has(id, cents(amount));
    }

    public boolean has(OfflinePlayer player, String world, double amount) {
        return this.has(player, amount);
    }

    public boolean has(String name, String world, double amount) {
        return this.has(name, amount);
    }

    /* ---------- Abheben / Einzahlen ---------- */

    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        if (amount < 0.0) {
            return this.fail("Negativer Betrag.");
        }
        UUID id = player.getUniqueId();
        if (!Economy.take(id, cents(amount))) {
            return new EconomyResponse(0.0, Economy.balance(id), ResponseType.FAILURE, "Nicht genug Geld.");
        }
        Audit.log("VAULT", "withdraw " + player.getName() + " (" + id + ") " + cents(amount));
        return new EconomyResponse(amount, Economy.balance(id), ResponseType.SUCCESS, "");
    }

    public EconomyResponse withdrawPlayer(String name, double amount) {
        UUID id = this.idOf(name);
        if (id == null) {
            return this.fail("Spieler unbekannt.");
        }
        return this.withdrawPlayer(this.plugin.getServer().getOfflinePlayer(id), amount);
    }

    public EconomyResponse withdrawPlayer(OfflinePlayer player, String world, double amount) {
        return this.withdrawPlayer(player, amount);
    }

    public EconomyResponse withdrawPlayer(String name, String world, double amount) {
        return this.withdrawPlayer(name, amount);
    }

    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        if (amount < 0.0) {
            return this.fail("Negativer Betrag.");
        }
        UUID id = player.getUniqueId();
        Economy.add(id, player.getName(), cents(amount));
        Audit.log("VAULT", "deposit " + player.getName() + " (" + id + ") " + cents(amount));
        return new EconomyResponse(amount, Economy.balance(id), ResponseType.SUCCESS, "");
    }

    public EconomyResponse depositPlayer(String name, double amount) {
        UUID id = this.idOf(name);
        if (id == null) {
            return this.fail("Spieler unbekannt.");
        }
        return this.depositPlayer(this.plugin.getServer().getOfflinePlayer(id), amount);
    }

    public EconomyResponse depositPlayer(OfflinePlayer player, String world, double amount) {
        return this.depositPlayer(player, amount);
    }

    public EconomyResponse depositPlayer(String name, String world, double amount) {
        return this.depositPlayer(name, amount);
    }

    /* ---------- Banken (nicht unterstuetzt) ---------- */

    public EconomyResponse createBank(String name, String player) {
        return this.noBank();
    }

    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return this.noBank();
    }

    public EconomyResponse deleteBank(String name) {
        return this.noBank();
    }

    public EconomyResponse bankBalance(String name) {
        return this.noBank();
    }

    public EconomyResponse bankHas(String name, double amount) {
        return this.noBank();
    }

    public EconomyResponse bankWithdraw(String name, double amount) {
        return this.noBank();
    }

    public EconomyResponse bankDeposit(String name, double amount) {
        return this.noBank();
    }

    public EconomyResponse isBankOwner(String name, String playerName) {
        return this.noBank();
    }

    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return this.noBank();
    }

    public EconomyResponse isBankMember(String name, String playerName) {
        return this.noBank();
    }

    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return this.noBank();
    }

    public List<String> getBanks() {
        return new ArrayList<String>();
    }
}
