package de.server.network;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

/**
 * Tag und Nacht nur im SMP und Bau-SMP, auch wenn beide in EINER Welt liegen:
 * - Alle anderen Modi (Lobby, Duell, Event, Parkour) sehen dauerhaft Mittag und klares Wetter (Spielerzeit, nur Anzeige).
 * - SMP folgt der echten Weltzeit (echtes Schlafen, siehe Sleep).
 * - Bau-SMP hat in einer geteilten Welt eine eigene Uhr: Weltzeit + Versatz, als relative Spielerzeit gesendet. Geschlafen wird "virtuell":
 *   Rechtsklick aufs Bett bei Bau-Nacht zaehlt als Schlafwunsch; ab sleep.percent der Bau-Spieler wird es in der Bau-Uhr Morgen.
 * Liegt das Bau-SMP in einer eigenen Welt, gilt dort die echte Weltzeit und Sleep funktioniert pro Welt.
 * Grenzen: Monster-Spawns, Pflanzenwachstum und Wetter folgen der echten Weltzeit (also dem SMP); nur die Anzeige und das Schlafen sind getrennt.
 */
final class WorldTime implements Listener {
    static WorldTime instance;

    private final DuelNetworkPlugin plugin;
    private long bauOffset;
    private final Map<UUID, String> applied = new HashMap<UUID, String>();
    private final Map<UUID, Long> wishes = new HashMap<UUID, Long>();
    private boolean skipping;

    WorldTime(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
        instance = this;
        this.bauOffset = plugin.getConfig().getLong("time.bau-offset", 0L);
        plugin.getServer().getScheduler().runTaskTimer((Plugin)plugin, Perf.wrap("WorldTime", this::tick), 40L, 20L);
        plugin.getServer().getScheduler().runTaskLater((Plugin)plugin, this::disableVanillaSleep, 100L);
    }

    /** Bau-SMP und SMP teilen sich eine Welt (dann braucht Bau eine eigene Uhr). */
    private boolean shared() {
        return !this.plugin.bauHasOwnBorder();
    }

    private void disableVanillaSleep() {
        // Vanilla-Schlafregel abschalten (101 % = nie), damit nur unsere Abstimmung zaehlt
        for (World world : this.plugin.getServer().getWorlds()) {
            try {
                world.setGameRule(org.bukkit.GameRule.PLAYERS_SLEEPING_PERCENTAGE, 101);
            }
            catch (Throwable ignored) {
                // Regel in dieser Version nicht vorhanden
            }
        }
    }

    private static boolean night(long time) {
        long t = ((time % 24000L) + 24000L) % 24000L;
        return t >= 12541L && t < 23460L;
    }

    /** Bau-Uhrzeit in einer geteilten Welt. */
    long bauNow(World world) {
        return ((world.getTime() + this.bauOffset) % 24000L + 24000L) % 24000L;
    }

    /** Vor einem Zeitsprung der Welt (Sleep) aufrufen: merkt die Bau-Uhr; danach finishSkip(). */
    long beginSkip(World world) {
        return this.shared() ? this.bauNow(world) : -1L;
    }

    void finishSkip(World world, long bauBefore) {
        if (bauBefore < 0L) {
            return;
        }
        this.bauOffset = ((bauBefore - world.getTime()) % 24000L + 24000L) % 24000L;
        this.applied.entrySet().removeIf(e -> e.getValue().startsWith("bau"));
    }

    private void tick() {
        boolean shared = this.shared();
        for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            UUID id = player.getUniqueId();
            String wanted;
            if (!Zone.survival(this.plugin, player)) {
                wanted = "fixed";
            } else if (shared && this.plugin.inBauMode(id)) {
                wanted = "bau:" + this.bauOffset;
            } else {
                wanted = "world";
            }
            if (wanted.equals(this.applied.get(id))) {
                continue;
            }
            this.applied.put(id, wanted);
            try {
                if (wanted.equals("fixed")) {
                    player.setPlayerTime(6000L, false);
                    player.setPlayerWeather(WeatherType.CLEAR);
                } else if (wanted.startsWith("bau")) {
                    player.setPlayerTime(this.bauOffset, true);
                    player.resetPlayerWeather();
                } else {
                    player.resetPlayerTime();
                    player.resetPlayerWeather();
                }
            }
            catch (Throwable t) {
                Store.problem("WorldTime:apply", t);
            }
        }
        long nowMs = System.currentTimeMillis();
        this.wishes.entrySet().removeIf(e -> {
            Player p = this.plugin.getServer().getPlayer(e.getKey());
            return p == null || nowMs - e.getValue() > 60000L || !this.plugin.inBauMode(e.getKey()) || !Zone.survival(this.plugin, p);
        });
        if (this.wishes.isEmpty()) {
            for (World w : this.plugin.getServer().getWorlds()) {
                SleepBar.hide(w.getName() + ":bau-virtual");
            }
        }
    }

    /** Bau-SMP in geteilter Welt: echtes Bett ersetzen wir durch die virtuelle Abstimmung. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBed(PlayerBedEnterEvent event) {
        Player player = event.getPlayer();
        if (!this.shared() || !Zone.survival(this.plugin, player) || !this.plugin.inBauMode(player.getUniqueId())) {
            return;
        }
        event.setCancelled(true);
        World world = player.getWorld();
        if (!night(this.bauNow(world))) {
            player.sendMessage("§cIm Bau-SMP ist gerade Tag – du kannst nur nachts schlafen.");
            return;
        }
        this.wishes.put(player.getUniqueId(), System.currentTimeMillis());
        List<Player> group = new ArrayList<Player>();
        int sleeping = 0;
        long now = System.currentTimeMillis();
        for (Player p : world.getPlayers()) {
            if (!Zone.survival(this.plugin, p) || !this.plugin.inBauMode(p.getUniqueId()) || p.getGameMode() == GameMode.SPECTATOR || Afk.isAfk(p)) {
                continue;
            }
            group.add(p);
            Long wish = this.wishes.get(p.getUniqueId());
            if (wish != null && now - wish < 60000L) {
                sleeping++;
            }
        }
        int percent = Math.max(1, Math.min(100, this.plugin.getConfig().getInt("sleep.percent", 30)));
        int needed = Math.max(1, (int)Math.ceil(group.size() * percent / 100.0));
        if (this.plugin.getConfig().getBoolean("sleep.bossbar", true)) {
            SleepBar.show(world.getName() + ":bau-virtual", group, sleeping, needed, "(Bau-SMP)");
        } else {
            for (Player p : group) {
                p.sendActionBar(net.kyori.adventure.text.Component.text("§e☾ §f" + sleeping + "/" + needed + " §7möchten schlafen §8(Bau-SMP)"));
            }
        }
        if (sleeping >= needed && !this.skipping) {
            this.skipping = true;
            this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
                this.skipping = false;
                this.bauOffset = ((24000L - world.getTime() % 24000L) % 24000L + 24000L) % 24000L;
                SleepBar.hide(world.getName() + ":bau-virtual");
                int gems = this.plugin.getConfig().getInt("sleep.reward-gems", 0);
                for (UUID wid : new ArrayList<UUID>(this.wishes.keySet())) {
                    Player wp = this.plugin.getServer().getPlayer(wid);
                    if (wp != null && gems > 0) {
                        Gems.give(wid, gems);
                    }
                    if (wp != null) {
                        wp.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.REGENERATION, 100, 0));
                        try {
                            wp.setStatistic(org.bukkit.Statistic.TIME_SINCE_REST, 0);
                        }
                        catch (Throwable ignored) {
                            // Statistik nicht verfuegbar
                        }
                    }
                }
                this.wishes.clear();
                this.applied.entrySet().removeIf(e -> e.getValue().startsWith("bau"));
                for (Player p : world.getPlayers()) {
                    if (this.plugin.inBauMode(p.getUniqueId()) && Zone.survival(this.plugin, p)) {
                        p.sendMessage("§e☀ §7Im Bau-SMP wurde die Nacht übersprungen.");
                    }
                }
                this.plugin.getConfig().set("time.bau-offset", this.bauOffset);
                this.plugin.saveConfig();
            }, group.size() <= 1 ? 10L : 60L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.applied.remove(event.getPlayer().getUniqueId());
        this.wishes.remove(event.getPlayer().getUniqueId());
    }
}
