package de.server.network;

import org.bukkit.entity.Player;

/** Hilfen fuer "nur SMP und Bau-SMP": beide laufen mit dem Profil "smp", das Bau-SMP zusaetzlich mit dem Bau-Flag. */
final class Zone {
    private Zone() { }

    /** true im SMP oder Bau-SMP (nicht Lobby, Duell, Event, Parkour). */
    static boolean survival(DuelNetworkPlugin plugin, Player player) {
        java.util.UUID id = player.getUniqueId();
        return "smp".equals(plugin.profiles.getOrDefault(id, "lobby")) && !plugin.activeDuelPlayers.contains(id)
                && !plugin.activePartyMatches.containsKey(id) && !plugin.activeParkourMaps.containsKey(id);
    }

    /** "bau" oder "smp" (fuer getrennte Daten). */
    static String key(DuelNetworkPlugin plugin, Player player) {
        return plugin.inBauMode(player.getUniqueId()) ? "bau" : "smp";
    }
}
