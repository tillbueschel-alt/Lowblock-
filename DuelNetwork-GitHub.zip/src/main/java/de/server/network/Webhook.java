package de.server.network;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Schickt Meldungen an einen Discord-Webhook (config: webhook.url, webhook.events). Laeuft asynchron und
 * darf nie den Server stoeren: Fehler werden nur einmal pro Minute geloggt.
 */
final class Webhook {
    private static long lastError;

    private Webhook() { }

    /** Optionaler Status-Post (config webhook.status-minutes > 0, "status" in webhook.events): Spieler, TPS, MSPT. */
    static void startStatus(DuelNetworkPlugin plugin) {
        int minutes = plugin.getConfig().getInt("webhook.status-minutes", 0);
        if (minutes <= 0) {
            return;
        }
        long ticks = Math.max(1, minutes) * 1200L;
        plugin.getServer().getScheduler().runTaskTimer((Plugin)plugin, Perf.wrap("WebhookStatus", () -> {
            double tps = Math.min(20.0, plugin.getServer().getTPS()[0]);
            send(plugin, "status", "Status: " + plugin.getServer().getOnlinePlayers().size() + " Spieler online, TPS " + String.format(java.util.Locale.ROOT, "%.1f", tps)
                    + ", MSPT " + String.format(java.util.Locale.ROOT, "%.1f", plugin.getServer().getAverageTickTime()));
        }), ticks, ticks);
    }

    /** event: anticheat, report, season, duel, join (muss in webhook.events stehen). */
    static void send(JavaPlugin plugin, String event, String text) {
        try {
            String url = plugin.getConfig().getString("webhook.url", "");
            List<String> events = plugin.getConfig().getStringList("webhook.events");
            if (url == null || url.isBlank() || !events.contains(event) || text == null) {
                return;
            }
            String clean = text.replaceAll("§.", "");
            if (clean.length() > 1800) {
                clean = clean.substring(0, 1800);
            }
            String body = "{\"username\":\"LowBlock\",\"content\":\"" + escape(clean) + "\"}";
            plugin.getServer().getScheduler().runTaskAsynchronously((Plugin)plugin, () -> post(plugin, url, body));
        }
        catch (Throwable t) {
            Store.problem("Webhook:send", t);
        }
    }

    private static String escape(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> { }
                default -> sb.append(c < 32 ? ' ' : c);
            }
        }
        return sb.toString();
    }

    private static void post(JavaPlugin plugin, String url, String body) {
        try {
            HttpURLConnection conn = (HttpURLConnection)URI.create(url).toURL().openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            try (OutputStream out = conn.getOutputStream()) {
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            if (code >= 300 && System.currentTimeMillis() - lastError > 60000L) {
                lastError = System.currentTimeMillis();
                plugin.getLogger().warning("Discord-Webhook antwortete mit HTTP " + code);
            }
            conn.disconnect();
        }
        catch (Exception ex) {
            if (System.currentTimeMillis() - lastError > 60000L) {
                lastError = System.currentTimeMillis();
                plugin.getLogger().warning("Discord-Webhook fehlgeschlagen: " + ex.getClass().getSimpleName());
            }
        }
    }
}
