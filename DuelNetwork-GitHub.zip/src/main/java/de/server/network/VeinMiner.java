package de.server.network;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Vein Miner nur im Bau-SMP: Wer ein Erz mit einer Spitzhacke abbaut, baut die ganze zusammenhaengende Ader ab
 * (gleiches Erz, auch diagonal). Schleichen = nur ein Block.
 * Config: bausmp.veinminer.enabled (true), bausmp.veinminer.max-blocks (64).
 */
final class VeinMiner implements Listener {
    private final DuelNetworkPlugin plugin;
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();

    static VeinMiner instance;

    VeinMiner(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
        instance = this;
    }

    static boolean busyFor(UUID id) {
        return instance != null && instance.busy.contains(id);
    }

    /** Erzgruppe: Stein- und Tiefenschiefer-Variante zaehlen als dasselbe Erz. Null = kein Erz. */
    private static String group(Material m) {
        String n = m.name();
        if (n.equals("ANCIENT_DEBRIS")) {
            return n;
        }
        if (!n.endsWith("_ORE")) {
            return null;
        }
        return n.startsWith("DEEPSLATE_") ? n.substring("DEEPSLATE_".length()) : n;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (this.busy.contains(id) || player.getGameMode() != GameMode.SURVIVAL || player.isSneaking()
                || !this.plugin.inBauMode(id) || !this.plugin.getConfig().getBoolean("bausmp.veinminer.enabled", true)) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null || !tool.getType().name().endsWith("_PICKAXE")) {
            return;
        }
        if (Gems.isHammer(tool)) {
            return; // die Hammer-Spitzhacke hat ihr eigenes 3x3
        }
        Block origin = event.getBlock();
        String kind = group(origin.getType());
        if (kind == null) {
            return;
        }
        int max = Math.max(1, Math.min(256, this.plugin.getConfig().getInt("bausmp.veinminer.max-blocks", 64)));
        Set<Block> vein = new HashSet<Block>();
        ArrayDeque<Block> queue = new ArrayDeque<Block>();
        vein.add(origin);
        queue.add(origin);
        while (!queue.isEmpty() && vein.size() < max) {
            Block c = queue.poll();
            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        Block n = c.getRelative(x, y, z);
                        if (vein.size() < max && kind.equals(group(n.getType())) && vein.add(n)) {
                            queue.add(n);
                        }
                    }
                }
            }
        }
        if (vein.size() <= 1) {
            return;
        }
        int broken = 1;
        this.busy.add(id);
        try {
            for (Block b : vein) {
                if (b.equals(origin)) {
                    continue;
                }
                if (Gems.nearlyBroken(tool)) {
                    player.sendMessage("§cDeine Spitzhacke ist fast kaputt - die Ader bleibt teilweise stehen.");
                    break;
                }
                BlockBreakEvent test = new BlockBreakEvent(b, player);
                this.plugin.getServer().getPluginManager().callEvent(test);
                if (test.isCancelled()) {
                    continue;
                }
                try {
                    b.breakNaturally(tool, true, true);
                }
                catch (NoSuchMethodError old) {
                    b.breakNaturally(tool);
                }
                Gems.wear(tool, 1);
                broken++;
            }
        }
        finally {
            this.busy.remove(id);
        }
        player.sendActionBar(net.kyori.adventure.text.Component.text("§b⛏ §7Ader abgebaut: §f" + broken + " Erze §8(Schleichen = nur ein Block)"));
    }
}
