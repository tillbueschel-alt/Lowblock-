package de.server.network;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Anti-X-Ray (Verhaltens-Erkennung): X-Ray-Spieler graben Tunnel direkt zu Erzen, die man von aussen nie gesehen hat.
 * Gezaehlt werden wertvolle Erze (Diamant, Smaragd, Antiker Schutt, Gold), die beim Abbau KEINE natuerlich freie Seite hatten
 * (keine Hoehle, kein Wasser/Lava; selbst gegrabene Luft zaehlt nicht), im Verhaeltnis zu allen abgebauten Steinbloecken.
 * Eine zusammenhaengende Ader zaehlt nur einmal. Ueber der Grenze gibt es Verstoss-Punkte (Check "XRay") und eine Admin-Warnung.
 *
 * Config (anticheat.xray): enabled (true), window-minutes (15), min-hidden (5), min-ratio (0.04).
 * Die Engine gegen X-Ray-Texturpakete (Paper: anticheat.anti-xray in paper-world-defaults.yml) ergaenzt das.
 */
final class XRay implements Listener {
    private static final class Data {
        final ArrayDeque<Long> mined = new ArrayDeque<Long>();
        final ArrayDeque<Long> hidden = new ArrayDeque<Long>();
        final ArrayDeque<int[]> broken = new ArrayDeque<int[]>();   // x, y, z, Zeit/1000 (nur eigene Abbauten, begrenzt)
        final ArrayDeque<int[]> ores = new ArrayDeque<int[]>();     // letzte wertvolle Erze (fuer "gleiche Ader")
    }

    private final DuelNetworkPlugin plugin;
    private final Map<UUID, Data> data = new ConcurrentHashMap<UUID, Data>();

    XRay(DuelNetworkPlugin plugin) {
        this.plugin = plugin;
    }

    private static boolean valuable(Material m) {
        String n = m.name();
        return n.equals("DIAMOND_ORE") || n.equals("DEEPSLATE_DIAMOND_ORE") || n.equals("EMERALD_ORE") || n.equals("DEEPSLATE_EMERALD_ORE")
                || n.equals("ANCIENT_DEBRIS") || n.equals("GOLD_ORE") || n.equals("DEEPSLATE_GOLD_ORE");
    }

    private static boolean stoneLike(Material m) {
        String n = m.name();
        return n.equals("STONE") || n.equals("DEEPSLATE") || n.equals("NETHERRACK") || n.equals("ANDESITE") || n.equals("DIORITE") || n.equals("GRANITE")
                || n.equals("TUFF") || n.equals("BASALT") || n.equals("BLACKSTONE") || n.equals("END_STONE") || n.equals("CALCITE") || n.endsWith("_ORE");
    }

    private static boolean naturallyOpen(Material m) {
        String n = m.name();
        return m.isAir() || n.equals("WATER") || n.equals("LAVA") || n.equals("CAVE_AIR") || n.equals("VOID_AIR");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.data.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        try {
            Player player = event.getPlayer();
            if (!AntiCheat.active() || !this.plugin.getConfig().getBoolean("anticheat.xray.enabled", true) || player.hasPermission("duelnetwork.anticheat.bypass")
                    || player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR || AntiCheat.skipBreak(player)
                    || this.plugin.inBauMode(player.getUniqueId()) || !"smp".equals(this.plugin.profiles.getOrDefault(player.getUniqueId(), "lobby"))) {
                return;
            }
            Block block = event.getBlock();
            Material type = block.getType();
            boolean ore = valuable(type);
            if (!ore && !stoneLike(type)) {
                return;
            }
            long now = System.currentTimeMillis();
            long windowMs = Math.max(1L, this.plugin.getConfig().getLong("anticheat.xray.window-minutes", 15L)) * 60000L;
            Data d = this.data.computeIfAbsent(player.getUniqueId(), id -> new Data());
            d.mined.addLast(now);
            while (!d.mined.isEmpty() && now - d.mined.peekFirst() > windowMs) {
                d.mined.pollFirst();
            }
            while (!d.hidden.isEmpty() && now - d.hidden.peekFirst() > windowMs) {
                d.hidden.pollFirst();
            }
            int x = block.getX();
            int y = block.getY();
            int z = block.getZ();
            if (ore) {
                boolean sameVein = false;
                Iterator<int[]> it = d.ores.iterator();
                while (it.hasNext()) {
                    int[] o = it.next();
                    if (now / 1000L - o[3] > 90L) {
                        it.remove();
                        continue;
                    }
                    if (Math.abs(o[0] - x) <= 2 && Math.abs(o[1] - y) <= 2 && Math.abs(o[2] - z) <= 2) {
                        sameVein = true;
                    }
                }
                d.ores.addLast(new int[]{x, y, z, (int)(now / 1000L)});
                while (d.ores.size() > 30) {
                    d.ores.pollFirst();
                }
                if (!sameVein && !this.exposedNaturally(block, d)) {
                    d.hidden.addLast(now);
                    int hidden = d.hidden.size();
                    int minedCount = d.mined.size();
                    int minHidden = Math.max(2, this.plugin.getConfig().getInt("anticheat.xray.min-hidden", 5));
                    double minRatio = Math.max(0.005, this.plugin.getConfig().getDouble("anticheat.xray.min-ratio", 0.04));
                    double ratio = hidden / (double)Math.max(1, minedCount);
                    if (hidden >= minHidden && ratio >= minRatio) {
                        AntiCheat.report(player, "XRay", 1.0, hidden + " verdeckte Erze bei nur " + minedCount + " Steinen in " + (windowMs / 60000L) + " Min (Verhältnis "
                                + String.format(java.util.Locale.ROOT, "%.3f", ratio) + ")");
                    }
                }
            }
            d.broken.addLast(new int[]{x, y, z, (int)(now / 1000L)});
            while (d.broken.size() > 120) {
                d.broken.pollFirst();
            }
        }
        catch (Throwable t) {
            Store.problem("XRay:onBreak", t);
        }
    }

    /** true, wenn eine Seite des Erzes von Natur aus frei war (Hoehle/Wasser/Lava) - selbst gegrabene Luft zaehlt nicht. */
    private boolean exposedNaturally(Block ore, Data d) {
        int[][] dirs = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        for (int[] dir : dirs) {
            Block n = ore.getRelative(dir[0], dir[1], dir[2]);
            if (!naturallyOpen(n.getType())) {
                continue;
            }
            boolean ownTunnel = false;
            for (int[] b : d.broken) {
                if (b[0] == n.getX() && b[1] == n.getY() && b[2] == n.getZ()) {
                    ownTunnel = true;
                    break;
                }
            }
            if (!ownTunnel) {
                return true;
            }
        }
        return false;
    }
}
