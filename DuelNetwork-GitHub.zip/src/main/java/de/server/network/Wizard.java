package de.server.network;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Erstell-Assistent fuer Auktionshaus und Orders - komplett per Menue, ohne Chat-Eingabe:
 * Item waehlen -> (Menge) -> Preis mit Plus/Minus-Knoepfen -> Bestaetigen.
 * Beim Auktionshaus wird das Item erst beim Bestaetigen aus dem Inventar genommen (vorher kann nichts verloren gehen).
 */
final class Wizard implements Listener {
    static final String TAG = "Erstellen";
    static Wizard instance;

    enum Mode { AH, ORDER }

    private enum Step { ITEM, PICK, AMOUNT, PRICE, CONFIRM }

    private static final long MAX_PRICE = 1_000_000_000L;
    private static final int MAX_AMOUNT = 2304;
    private static final long[] PRICE_STEPS = {1L, 10L, 100L, 1_000L, 10_000L, 100_000L, 1_000_000L};
    private static final String[] PRICE_LABELS = {"1", "10", "100", "1K", "10K", "100K", "1M"};
    private static final long[] AMOUNT_STEPS = {1L, 8L, 16L, 32L, 64L, 128L, 256L};
    private static final String[] AMOUNT_LABELS = {"1", "8", "16", "32", "64", "128", "256"};
    private static final int[] ROW_PLUS = {10, 11, 12, 13, 14, 15, 16};
    private static final int[] ROW_MINUS = {28, 29, 30, 31, 32, 33, 34};

    private static final class Session {
        Mode mode;
        Step step = Step.ITEM;
        int invSlot = -1;
        ItemStack proto;
        Material material;
        int amount = 1;
        long price = 1L;
        int page;
    }

    private static List<Material> catalog;

    private final DuelNetworkPlugin plugin;
    private final AuctionHouse ah;
    private final Orders orders;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();

    Wizard(DuelNetworkPlugin plugin, AuctionHouse ah, Orders orders) {
        this.plugin = plugin;
        this.ah = ah;
        this.orders = orders;
        instance = this;
    }

    private static synchronized List<Material> catalog() {
        if (catalog == null) {
            List<Material> list = new ArrayList<Material>();
            for (Material m : Material.values()) {
                if (m.isItem() && !m.isAir() && !m.name().startsWith("LEGACY_") && !Gui.blocked(m)) {
                    list.add(m);
                }
            }
            list.sort(Comparator.comparing(Material::name));
            catalog = list;
        }
        return catalog;
    }

    void start(Player player, Mode mode) {
        Session s = new Session();
        s.mode = mode;
        this.sessions.put(player.getUniqueId(), s);
        this.render(player, s);
    }

    /* ---------- Darstellung ---------- */

    private static ItemStack btn(Material m, String name, String... lore) {
        return Gui.item(m, name, lore);
    }

    private void render(Player player, Session s) {
        String what = s.mode == Mode.AH ? "Angebot erstellen" : "Order erstellen";
        Inventory inv;
        switch (s.step) {
            case ITEM -> {
                inv = Gui.frame(this.plugin, TAG, what + " §8• §dItem", 27);
                if (s.proto == null) {
                    inv.setItem(13, btn(Material.PAPER, "§7Noch kein Item gewählt",
                            s.mode == Mode.AH ? "§7Klicke ein Item in deinem Inventar an." : "§7Klicke ein Item in deinem Inventar an",
                            s.mode == Mode.AH ? "§8Linksklick: ganzer Stapel • Rechtsklick: 1 Stück" : "§7oder wähle es aus der Liste."));
                } else {
                    inv.setItem(13, this.shownItem(s, "§aGewählt: §f" + Gui.prettyName(s.material), "§7Anzahl: §f" + s.amount, "§e▶ Klicken: wieder entfernen"));
                    inv.setItem(26, btn(Material.ARROW, "§a§lWeiter »", "§7Als Nächstes: " + (s.mode == Mode.AH ? "Preis" : "Menge")));
                }
                if (s.mode == Mode.ORDER) {
                    inv.setItem(11, btn(Material.BOOK, "§e§lItem-Liste", "§7Alle Items durchblättern", "§e▶ Klicken"));
                }
                inv.setItem(18, btn(Material.BARRIER, "§c§lAbbrechen"));
            }
            case PICK -> {
                inv = Gui.frame(this.plugin, TAG, "Item-Liste", 54);
                List<Material> all = catalog();
                int pages = Math.max(1, (all.size() + 44) / 45);
                s.page = Math.max(0, Math.min(s.page, pages - 1));
                for (int i = 0; i < 45; i++) {
                    int idx = s.page * 45 + i;
                    inv.setItem(i, idx < all.size() ? Gui.item(all.get(idx), "§f" + Gui.prettyName(all.get(idx)), "§e▶ Klicken: auswählen") : null);
                }
                inv.setItem(45, btn(Material.ARROW, "§7« Vorherige Seite"));
                inv.setItem(46, btn(Material.PAPER, "§dSeite " + (s.page + 1) + "/" + pages));
                inv.setItem(49, btn(Material.BARRIER, "§c§lAbbrechen", "§7Zurück zur Auswahl"));
                inv.setItem(53, btn(Material.ARROW, "§7Nächste Seite »"));
            }
            case AMOUNT -> {
                inv = Gui.frame(this.plugin, TAG, "Menge wählen", 45);
                this.fillAdjust(inv, s, AMOUNT_STEPS, AMOUNT_LABELS);
                inv.setItem(22, this.shownItem(s, "§fMenge: §a" + s.amount + "x", "§7Max. " + MAX_AMOUNT, "§e▶ Klicken: auf 1 setzen"));
                inv.setItem(36, btn(Material.ARROW, "§7« Zurück"));
                inv.setItem(44, btn(Material.ARROW, "§a§lWeiter »", "§7Als Nächstes: Preis pro Stück"));
            }
            case PRICE -> {
                inv = Gui.frame(this.plugin, TAG, "Preis wählen", 45);
                this.fillAdjust(inv, s, PRICE_STEPS, PRICE_LABELS);
                inv.setItem(22, this.shownItem(s, "§fPreis" + (s.mode == Mode.ORDER ? " pro Stück" : "") + ": §a" + Gui.money(s.price),
                        s.mode == Mode.ORDER ? "§7Menge: §f" + s.amount + "x" : "§7Anzahl: §f" + s.amount + "x", "§e▶ Klicken: auf 1 setzen"));
                inv.setItem(36, btn(Material.ARROW, "§7« Zurück"));
                inv.setItem(44, btn(Material.ARROW, "§a§lWeiter »", "§7Als Nächstes: Bestätigen"));
            }
            default -> {
                inv = Gui.frame(this.plugin, TAG, "Bestätigen", 27);
                List<String> lore = new ArrayList<String>();
                if (s.mode == Mode.AH) {
                    long tax = Math.max(0L, Math.min(50L, this.plugin.getConfig().getLong("ah.tax-percent", 0L)));
                    lore.add("§7Anzahl: §f" + s.amount + "x");
                    lore.add("§7Preis: §a" + Gui.money(s.price));
                    lore.add("§7Du erhältst: §a" + Gui.money(Rules.proceeds(s.price, tax)) + (tax > 0L ? " §8(" + tax + "% Gebühr)" : ""));
                    lore.add("§7Laufzeit: §f" + Math.max(1L, this.plugin.getConfig().getLong("ah.duration-hours", 48L)) + " Std");
                } else {
                    long total = s.price * s.amount;
                    lore.add("§7Menge: §f" + s.amount + "x");
                    lore.add("§7Preis pro Stück: §a" + Gui.money(s.price));
                    lore.add("§7Wird hinterlegt: §a" + Gui.money(total));
                    lore.add(Economy.balance(player.getUniqueId()) >= total ? "§7Dein Geld: §a" + Gui.money(Economy.balance(player.getUniqueId())) : "§c✖ Dafür fehlt dir Geld (" + Gui.money(Economy.balance(player.getUniqueId())) + ")");
                }
                inv.setItem(13, this.shownItem(s, "§f" + Gui.prettyName(s.material), lore.toArray(new String[0])));
                inv.setItem(11, btn(Material.ARROW, "§7« Zurück"));
                inv.setItem(15, btn(Material.EMERALD, "§a§lBestätigen", s.mode == Mode.AH ? "§7Angebot jetzt einstellen" : "§7Order jetzt aufgeben"));
            }
        }
        player.openInventory(inv);
    }

    private ItemStack shownItem(Session s, String name, String... lore) {
        Material m = s.material == null ? Material.PAPER : s.material;
        return Gui.item(m, Math.max(1, Math.min(64, s.amount)), name, java.util.Arrays.asList(lore));
    }

    private void fillAdjust(Inventory inv, Session s, long[] steps, String[] labels) {
        for (int i = 0; i < steps.length; i++) {
            inv.setItem(ROW_PLUS[i], btn(Material.LIME_DYE, "§a+" + labels[i], "§7Klicken: erhöhen"));
            inv.setItem(ROW_MINUS[i], btn(Material.RED_DYE, "§c-" + labels[i], "§7Klicken: verringern"));
        }
        inv.setItem(20, btn(Material.GOLD_NUGGET, "§e÷ 2", "§7Halbieren"));
        inv.setItem(24, btn(Material.GOLD_INGOT, "§e× 2", "§7Verdoppeln"));
    }

    /* ---------- Klicks ---------- */

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (Gui.isTitle(event.getView().getTitle(), TAG)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!Gui.isTitle(event.getView().getTitle(), TAG) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        Session s = this.sessions.get(player.getUniqueId());
        if (s == null) {
            player.closeInventory();
            return;
        }
        int raw = event.getRawSlot();
        int topSize = event.getView().getTopInventory().getSize();
        if (raw < 0) {
            return;
        }
        if (raw >= topSize) {
            this.onBottomClick(player, s, event);
            return;
        }
        switch (s.step) {
            case ITEM -> this.clickItem(player, s, raw);
            case PICK -> this.clickPick(player, s, raw);
            case AMOUNT -> this.clickAdjust(player, s, raw, AMOUNT_STEPS, true);
            case PRICE -> this.clickAdjust(player, s, raw, PRICE_STEPS, false);
            default -> this.clickConfirm(player, s, raw);
        }
    }

    private void onBottomClick(Player player, Session s, InventoryClickEvent event) {
        if (s.step != Step.ITEM || event.getClickedInventory() != player.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        ItemStack clicked = event.getCurrentItem();
        if (slot < 0 || slot > 35 || clicked == null || clicked.getType() == Material.AIR) {
            return;
        }
        if (Gui.blocked(clicked.getType())) {
            Chat.no(player);
            player.sendMessage("§cDieses Item kann nicht gehandelt werden.");
            return;
        }
        s.material = clicked.getType();
        s.proto = clicked.clone();
        if (s.mode == Mode.AH) {
            s.invSlot = slot;
            s.amount = event.isRightClick() ? 1 : clicked.getAmount();
        } else {
            s.invSlot = -1;
            s.amount = Math.min(MAX_AMOUNT, Math.max(1, clicked.getMaxStackSize()));
        }
        this.render(player, s);
    }

    private void clickItem(Player player, Session s, int slot) {
        if (slot == 18) {
            this.finish(player);
        } else if (slot == 13 && s.proto != null) {
            s.proto = null;
            s.material = null;
            s.invSlot = -1;
            this.render(player, s);
        } else if (slot == 11 && s.mode == Mode.ORDER) {
            s.step = Step.PICK;
            s.page = 0;
            this.render(player, s);
        } else if (slot == 26 && s.proto != null) {
            s.step = s.mode == Mode.AH ? Step.PRICE : Step.AMOUNT;
            this.render(player, s);
        }
    }

    private void clickPick(Player player, Session s, int slot) {
        if (slot == 45) {
            s.page--;
            this.render(player, s);
        } else if (slot == 53) {
            s.page++;
            this.render(player, s);
        } else if (slot == 49) {
            s.step = Step.ITEM;
            this.render(player, s);
        } else if (slot < 45) {
            List<Material> all = catalog();
            int idx = s.page * 45 + slot;
            if (idx < all.size()) {
                s.material = all.get(idx);
                s.proto = new ItemStack(s.material);
                s.amount = Math.min(MAX_AMOUNT, s.material.getMaxStackSize());
                s.step = Step.ITEM;
                this.render(player, s);
            }
        }
    }

    private void clickAdjust(Player player, Session s, int slot, long[] steps, boolean amountMode) {
        long value = amountMode ? s.amount : s.price;
        long max = amountMode ? MAX_AMOUNT : MAX_PRICE;
        boolean changed = false;
        for (int i = 0; i < steps.length; i++) {
            if (slot == ROW_PLUS[i]) {
                value += steps[i];
                changed = true;
            } else if (slot == ROW_MINUS[i]) {
                value -= steps[i];
                changed = true;
            }
        }
        if (slot == 24) {
            value *= 2L;
            changed = true;
        } else if (slot == 20) {
            value /= 2L;
            changed = true;
        } else if (slot == 22) {
            value = 1L;
            changed = true;
        }
        if (changed) {
            value = Math.max(1L, Math.min(max, value));
            if (amountMode) {
                s.amount = (int) value;
            } else {
                s.price = value;
            }
            this.render(player, s);
            return;
        }
        if (slot == 36) {
            s.step = amountMode ? Step.ITEM : (s.mode == Mode.AH ? Step.ITEM : Step.AMOUNT);
            this.render(player, s);
        } else if (slot == 44) {
            s.step = amountMode ? Step.PRICE : Step.CONFIRM;
            this.render(player, s);
        }
    }

    private void clickConfirm(Player player, Session s, int slot) {
        if (slot == 11) {
            s.step = Step.PRICE;
            this.render(player, s);
        } else if (slot == 15) {
            boolean ok;
            if (s.mode == Mode.AH) {
                ok = this.ah.listItem(player, s.invSlot, s.proto, s.amount, s.price);
            } else {
                ok = this.orders.placeOrder(player, s.material, s.amount, s.price);
            }
            this.sessions.remove(player.getUniqueId());
            player.closeInventory();
            if (ok) {
                this.plugin.getServer().getScheduler().runTask((Plugin) this.plugin, () -> {
                    if (player.isOnline()) {
                        if (s.mode == Mode.AH) {
                            this.ah.show(player, true);
                        } else {
                            this.orders.show(player, true);
                        }
                    }
                });
            }
        }
    }

    private void finish(Player player) {
        this.sessions.remove(player.getUniqueId());
        player.closeInventory();
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!Gui.isTitle(event.getView().getTitle(), TAG) || !(event.getPlayer() instanceof Player player)) {
            return;
        }
        // Beim Wechsel zwischen Schritten oeffnet sich sofort ein neues Wizard-Menue; nur wirklich beendete Sitzungen verwerfen
        this.plugin.getServer().getScheduler().runTask((Plugin) this.plugin, () -> {
            if (!Gui.isTitle(player.getOpenInventory().getTitle(), TAG)) {
                this.sessions.remove(player.getUniqueId());
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.sessions.remove(event.getPlayer().getUniqueId());
    }
}
